import ExteriorExponentialWeights_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.exteriorTaper
#check @TheoremT.Continuum.exteriorTaper_nonneg
#check @TheoremT.Continuum.exteriorTaper_le_one
#check @TheoremT.Continuum.exteriorTaper_contDiff
#check @TheoremT.Continuum.exteriorTaper_memLp_top
#check @TheoremT.Continuum.exteriorExpWeight
#check @TheoremT.Continuum.exteriorExpWeight_contDiff
#check @TheoremT.Continuum.exteriorExpWeight_memLp_top
#check @TheoremT.Continuum.exteriorExpWeight_zero_on_ball
#check @TheoremT.Continuum.exteriorTaper_eq_one_of_exterior
#check @TheoremT.Continuum.exteriorExpWeight_partial
#check @TheoremT.Continuum.exteriorExpWeight_partial_memLp_top
#check @TheoremT.Continuum.exteriorExpWeight_tendsto
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.exteriorTaper
#print axioms TheoremT.Continuum.exteriorTaper_nonneg
#print axioms TheoremT.Continuum.exteriorTaper_le_one
#print axioms TheoremT.Continuum.exteriorTaper_contDiff
#print axioms TheoremT.Continuum.exteriorTaper_memLp_top
#print axioms TheoremT.Continuum.exteriorExpWeight
#print axioms TheoremT.Continuum.exteriorExpWeight_contDiff
#print axioms TheoremT.Continuum.exteriorExpWeight_memLp_top
#print axioms TheoremT.Continuum.exteriorExpWeight_zero_on_ball
#print axioms TheoremT.Continuum.exteriorTaper_eq_one_of_exterior
#print axioms TheoremT.Continuum.exteriorExpWeight_partial
#print axioms TheoremT.Continuum.exteriorExpWeight_partial_memLp_top
#print axioms TheoremT.Continuum.exteriorExpWeight_tendsto
