import SO2SpectatorSeriesInvariance_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.so2SpectatorFamily_rotation_invariant_of_hasSum
#check @TheoremT.Continuum.so2SpectatorFamily_balanced_support_of_hasSum
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.so2SpectatorFamily_rotation_invariant_of_hasSum
#print axioms TheoremT.Continuum.so2SpectatorFamily_balanced_support_of_hasSum
