import PhysicalKSAxisPolynomialData_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.physicalKSAxisPolynomialA
#check @TheoremT.Continuum.physicalKSAxisPolynomialB
#check @TheoremT.Continuum.physicalKSAxisSeriesRate
#check @TheoremT.Continuum.PhysicalKSAxisPolynomialData
#check @TheoremT.Continuum.physicalKSAxisPolynomial_data_of_balanced
#check @TheoremT.Continuum.nuclearKSPhysicalAxisPolynomial_data
#check @TheoremT.Continuum.pairKSPhysicalAxisPolynomial_data
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.physicalKSAxisPolynomialA
#print axioms TheoremT.Continuum.physicalKSAxisPolynomialB
#print axioms TheoremT.Continuum.physicalKSAxisSeriesRate
#print axioms TheoremT.Continuum.PhysicalKSAxisPolynomialData
#print axioms TheoremT.Continuum.physicalKSAxisPolynomial_data_of_balanced
#print axioms TheoremT.Continuum.nuclearKSPhysicalAxisPolynomial_data
#print axioms TheoremT.Continuum.pairKSPhysicalAxisPolynomial_data
