import SpectatorScalingIteratedDerivativeWord_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.spectatorScaling_iteratedFDeriv_word
#check @TheoremT.Continuum.spectatorScaling_iteratedFDeriv_word_norm_le
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.spectatorScaling_iteratedFDeriv_word
#print axioms TheoremT.Continuum.spectatorScaling_iteratedFDeriv_word_norm_le
