import SO2AxisPolynomialRestriction_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.so2AxisPolynomialGenerator
#check @TheoremT.Continuum.so2AxisPolynomialRestriction
#check @TheoremT.Continuum.so2AxisPolynomialGenerator_homogeneous
#check @TheoremT.Continuum.so2AxisPolynomialGenerator_coeffL1
#check @TheoremT.Continuum.so2AxisPolynomialRestriction_homogeneous
#check @TheoremT.Continuum.so2AxisPolynomialRestriction_coeffL1
#check @TheoremT.Continuum.so2AxisPolynomialRestriction_eval
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.so2AxisPolynomialGenerator
#print axioms TheoremT.Continuum.so2AxisPolynomialRestriction
#print axioms TheoremT.Continuum.so2AxisPolynomialGenerator_homogeneous
#print axioms TheoremT.Continuum.so2AxisPolynomialGenerator_coeffL1
#print axioms TheoremT.Continuum.so2AxisPolynomialRestriction_homogeneous
#print axioms TheoremT.Continuum.so2AxisPolynomialRestriction_coeffL1
#print axioms TheoremT.Continuum.so2AxisPolynomialRestriction_eval
