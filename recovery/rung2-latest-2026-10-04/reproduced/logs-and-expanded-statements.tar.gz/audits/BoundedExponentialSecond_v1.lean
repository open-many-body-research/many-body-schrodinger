import BoundedExponentialSecond_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.boundedExpWeight_mixed_partial
#check @TheoremT.Continuum.boundedExpWeight_mixed_partial_abs_le
#check @TheoremT.Continuum.boundedExpWeight_mixed_partial_memLp_top
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.boundedExpWeight_mixed_partial
#print axioms TheoremT.Continuum.boundedExpWeight_mixed_partial_abs_le
#print axioms TheoremT.Continuum.boundedExpWeight_mixed_partial_memLp_top
