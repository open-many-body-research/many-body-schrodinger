import CoulombRotation_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.spatialRotation
#check @TheoremT.Continuum.spatialRotation_pullback
#check @TheoremT.Continuum.scalar_graph_spatialRotation
#check @TheoremT.Continuum.HasH2.spatialRotation
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.spatialRotation
#print axioms TheoremT.Continuum.spatialRotation_pullback
#print axioms TheoremT.Continuum.scalar_graph_spatialRotation
#print axioms TheoremT.Continuum.HasH2.spatialRotation
