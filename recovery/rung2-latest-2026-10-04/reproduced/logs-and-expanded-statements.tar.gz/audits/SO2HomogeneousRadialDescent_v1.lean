import SO2HomogeneousRadialDescent_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.so2ForwardPolynomial_mul
#check @TheoremT.Continuum.so2PolynomialToCartesian_balanced_power
#check @TheoremT.Continuum.so2_homogeneous_even_radial_descent
#check @TheoremT.Continuum.so2_homogeneous_odd_eq_zero
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.so2ForwardPolynomial_mul
#print axioms TheoremT.Continuum.so2PolynomialToCartesian_balanced_power
#print axioms TheoremT.Continuum.so2_homogeneous_even_radial_descent
#print axioms TheoremT.Continuum.so2_homogeneous_odd_eq_zero
