import SO2ComplexPolynomialCoordinates_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.so2ForwardPolynomial
#check @TheoremT.Continuum.so2InversePolynomial
#check @TheoremT.Continuum.so2PolynomialToBalanced
#check @TheoremT.Continuum.so2PolynomialToCartesian
#check @TheoremT.Continuum.so2InversePolynomial_forward
#check @TheoremT.Continuum.so2ForwardPolynomial_inverse
#check @TheoremT.Continuum.so2PolynomialToCartesian_toBalanced
#check @TheoremT.Continuum.so2PolynomialToBalanced_toCartesian
#check @TheoremT.Continuum.so2InversePolynomial_homogeneous
#check @TheoremT.Continuum.so2PolynomialToBalanced_homogeneous
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.so2ForwardPolynomial
#print axioms TheoremT.Continuum.so2InversePolynomial
#print axioms TheoremT.Continuum.so2PolynomialToBalanced
#print axioms TheoremT.Continuum.so2PolynomialToCartesian
#print axioms TheoremT.Continuum.so2InversePolynomial_forward
#print axioms TheoremT.Continuum.so2ForwardPolynomial_inverse
#print axioms TheoremT.Continuum.so2PolynomialToCartesian_toBalanced
#print axioms TheoremT.Continuum.so2PolynomialToBalanced_toCartesian
#print axioms TheoremT.Continuum.so2InversePolynomial_homogeneous
#print axioms TheoremT.Continuum.so2PolynomialToBalanced_homogeneous
