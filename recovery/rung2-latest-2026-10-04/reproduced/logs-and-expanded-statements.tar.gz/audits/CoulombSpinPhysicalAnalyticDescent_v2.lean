import CoulombSpinPhysicalAnalyticDescent_v2
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.coulomb_spin_physical_analytic_descent_derivative_representative
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.coulomb_spin_physical_analytic_descent_derivative_representative
