import TwoElectronGroundDecay_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.twoElectron_ground_exponential_decay
#check @TheoremT.Continuum.twoElectron_ground_decay_charge_sixteenth
#check @TheoremT.Continuum.twoElectron_ground_real_symmetric_rotation_decay
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.twoElectron_ground_exponential_decay
#print axioms TheoremT.Continuum.twoElectron_ground_decay_charge_sixteenth
#print axioms TheoremT.Continuum.twoElectron_ground_real_symmetric_rotation_decay
