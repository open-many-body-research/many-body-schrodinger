import BoundedExponentialWeights_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.boundedExpWeight
#check @TheoremT.Continuum.boundedExpWeight_pos
#check @TheoremT.Continuum.boundedExpWeight_le_cap
#check @TheoremT.Continuum.boundedExpWeight_le_exp
#check @TheoremT.Continuum.boundedExpWeight_contDiff
#check @TheoremT.Continuum.boundedExpWeight_partial
#check @TheoremT.Continuum.boundedExpWeight_partial_abs_le
#check @TheoremT.Continuum.boundedExpWeight_gradient_sq_le
#check @TheoremT.Continuum.boundedExpWeight_memLp_top
#check @TheoremT.Continuum.boundedExpWeight_partial_memLp_top
#check @TheoremT.Continuum.boundedExpWeight_tendsto
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.boundedExpWeight
#print axioms TheoremT.Continuum.boundedExpWeight_pos
#print axioms TheoremT.Continuum.boundedExpWeight_le_cap
#print axioms TheoremT.Continuum.boundedExpWeight_le_exp
#print axioms TheoremT.Continuum.boundedExpWeight_contDiff
#print axioms TheoremT.Continuum.boundedExpWeight_partial
#print axioms TheoremT.Continuum.boundedExpWeight_partial_abs_le
#print axioms TheoremT.Continuum.boundedExpWeight_gradient_sq_le
#print axioms TheoremT.Continuum.boundedExpWeight_memLp_top
#print axioms TheoremT.Continuum.boundedExpWeight_partial_memLp_top
#print axioms TheoremT.Continuum.boundedExpWeight_tendsto
