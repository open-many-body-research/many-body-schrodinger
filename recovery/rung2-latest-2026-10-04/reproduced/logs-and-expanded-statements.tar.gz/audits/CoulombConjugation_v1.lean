import CoulombConjugation_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.spatialConj
#check @TheoremT.Continuum.spatialConj_coeFn
#check @TheoremT.Continuum.spatialConj_smul
#check @TheoremT.Continuum.spatialConj_involutive
#check @TheoremT.Continuum.spatialConj_pullback
#check @TheoremT.Continuum.spatialConj_integral_test
#check @TheoremT.Continuum.weakPartial_conj
#check @TheoremT.Continuum.scalar_graph_conj
#check @TheoremT.Continuum.spatialConj_fixed_im_zero
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.spatialConj
#print axioms TheoremT.Continuum.spatialConj_coeFn
#print axioms TheoremT.Continuum.spatialConj_smul
#print axioms TheoremT.Continuum.spatialConj_involutive
#print axioms TheoremT.Continuum.spatialConj_pullback
#print axioms TheoremT.Continuum.spatialConj_integral_test
#print axioms TheoremT.Continuum.weakPartial_conj
#print axioms TheoremT.Continuum.scalar_graph_conj
#print axioms TheoremT.Continuum.spatialConj_fixed_im_zero
