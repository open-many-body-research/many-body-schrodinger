import SO2BalancedHomogeneousPolynomial_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.so2BalancedExponent
#check @TheoremT.Continuum.so2_homogeneous_support_degree
#check @TheoremT.Continuum.so2_balanced_homogeneous_even
#check @TheoremT.Continuum.so2_balanced_homogeneous_odd
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.so2BalancedExponent
#print axioms TheoremT.Continuum.so2_homogeneous_support_degree
#print axioms TheoremT.Continuum.so2_balanced_homogeneous_even
#print axioms TheoremT.Continuum.so2_balanced_homogeneous_odd
