import SO2SeriesFunctionIdentification_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.so2_series_function_eq_descended
#check @TheoremT.Continuum.so2_series_descended_full_polydisc_bound
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.so2_series_function_eq_descended
#print axioms TheoremT.Continuum.so2_series_descended_full_polydisc_bound
