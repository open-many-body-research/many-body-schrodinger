import SO2PolynomialSeriesInput_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.SO2PolynomialSeriesInput
#check @TheoremT.Continuum.so2PolynomialSeriesInput_of_joint_polynomials
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.SO2PolynomialSeriesInput
#print axioms TheoremT.Continuum.so2PolynomialSeriesInput_of_joint_polynomials
