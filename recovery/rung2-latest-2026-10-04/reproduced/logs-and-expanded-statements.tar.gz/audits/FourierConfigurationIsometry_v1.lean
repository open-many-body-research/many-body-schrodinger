import FourierConfigurationIsometry_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.configurationIsometryPull
#check @TheoremT.Continuum.configurationIsometryPull_ae
#check @TheoremT.Continuum.configurationIsometryPull_schwartz
#check @TheoremT.Continuum.fourier_configurationIsometryPull
#check @TheoremT.Continuum.configurationIsometryPull_fourier_weight
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.configurationIsometryPull
#print axioms TheoremT.Continuum.configurationIsometryPull_ae
#print axioms TheoremT.Continuum.configurationIsometryPull_schwartz
#print axioms TheoremT.Continuum.fourier_configurationIsometryPull
#print axioms TheoremT.Continuum.configurationIsometryPull_fourier_weight
