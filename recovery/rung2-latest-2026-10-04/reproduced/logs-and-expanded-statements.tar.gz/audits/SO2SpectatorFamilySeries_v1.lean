import SO2SpectatorFamilySeries_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.so2SpectatorFamily
#check @TheoremT.Continuum.so2SpectatorFamily_homogeneous
#check @TheoremT.Continuum.so2SpectatorFamily_coefficientL1
#check @TheoremT.Continuum.so2SpectatorFamily_grouped
#check @TheoremT.Continuum.so2SpectatorFamily_summable
#check @TheoremT.Continuum.so2SpectatorFamily_hasSum_of_joint_hasSum
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.so2SpectatorFamily
#print axioms TheoremT.Continuum.so2SpectatorFamily_homogeneous
#print axioms TheoremT.Continuum.so2SpectatorFamily_coefficientL1
#print axioms TheoremT.Continuum.so2SpectatorFamily_grouped
#print axioms TheoremT.Continuum.so2SpectatorFamily_summable
#print axioms TheoremT.Continuum.so2SpectatorFamily_hasSum_of_joint_hasSum
