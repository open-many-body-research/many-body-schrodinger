import KSRealSpectatorSeriesDerivative_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.ks_real_spectator_series_mixed_factorial_bounds
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.ks_real_spectator_series_mixed_factorial_bounds
