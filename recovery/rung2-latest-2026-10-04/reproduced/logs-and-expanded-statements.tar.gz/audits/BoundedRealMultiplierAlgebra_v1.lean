import BoundedRealMultiplierAlgebra_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.boundedRealMul_add
#check @TheoremT.Continuum.boundedRealMul_smul
#check @TheoremT.Continuum.boundedRealMul_real_inner
#check @TheoremT.Continuum.boundedRealMul_comm
#check @TheoremT.Continuum.boundedRealMul_norm_sq_integral
#check @TheoremT.Continuum.boundedRealMul_coulomb_ae
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.boundedRealMul_add
#print axioms TheoremT.Continuum.boundedRealMul_smul
#print axioms TheoremT.Continuum.boundedRealMul_real_inner
#print axioms TheoremT.Continuum.boundedRealMul_comm
#print axioms TheoremT.Continuum.boundedRealMul_norm_sq_integral
#print axioms TheoremT.Continuum.boundedRealMul_coulomb_ae
