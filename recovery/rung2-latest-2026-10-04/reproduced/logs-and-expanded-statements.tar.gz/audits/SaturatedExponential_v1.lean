import SaturatedExponential_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.saturatedExp
#check @TheoremT.Continuum.saturatedExp_pos
#check @TheoremT.Continuum.saturatedExp_le_cap
#check @TheoremT.Continuum.saturatedExp_le_exp
#check @TheoremT.Continuum.saturatedExp_contDiff
#check @TheoremT.Continuum.saturatedExp_hasDerivAt
#check @TheoremT.Continuum.saturatedExp_deriv_bounds
#check @TheoremT.Continuum.saturatedExp_eq_div
#check @TheoremT.Continuum.saturatedExp_tendsto
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.saturatedExp
#print axioms TheoremT.Continuum.saturatedExp_pos
#print axioms TheoremT.Continuum.saturatedExp_le_cap
#print axioms TheoremT.Continuum.saturatedExp_le_exp
#print axioms TheoremT.Continuum.saturatedExp_contDiff
#print axioms TheoremT.Continuum.saturatedExp_hasDerivAt
#print axioms TheoremT.Continuum.saturatedExp_deriv_bounds
#print axioms TheoremT.Continuum.saturatedExp_eq_div
#print axioms TheoremT.Continuum.saturatedExp_tendsto
