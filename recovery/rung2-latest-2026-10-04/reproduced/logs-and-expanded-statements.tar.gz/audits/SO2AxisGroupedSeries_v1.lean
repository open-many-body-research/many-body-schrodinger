import SO2AxisGroupedSeries_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.so2AxisGroupedPolynomial
#check @TheoremT.Continuum.so2AxisGroupedPolynomial_homogeneous
#check @TheoremT.Continuum.so2AxisGroupedPolynomial_coeffL1
#check @TheoremT.Continuum.so2_axis_coordinate_norm_le
#check @TheoremT.Continuum.so2AxisGroupedPolynomial_hasSum
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.so2AxisGroupedPolynomial
#print axioms TheoremT.Continuum.so2AxisGroupedPolynomial_homogeneous
#print axioms TheoremT.Continuum.so2AxisGroupedPolynomial_coeffL1
#print axioms TheoremT.Continuum.so2_axis_coordinate_norm_le
#print axioms TheoremT.Continuum.so2AxisGroupedPolynomial_hasSum
