import FourierDerivativeRepresentation_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.fourier_derivative_distribution_output
#check @TheoremT.Continuum.fourier_derivative_ae
#check @TheoremT.Continuum.fourier_derivative_product_memLp
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.fourier_derivative_distribution_output
#print axioms TheoremT.Continuum.fourier_derivative_ae
#print axioms TheoremT.Continuum.fourier_derivative_product_memLp
