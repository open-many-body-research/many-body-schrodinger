import ConfigurationRotation_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.rotateConfigurationLinear
#check @TheoremT.Continuum.position_rotateConfigurationLinear
#check @TheoremT.Continuum.configuration_norm_sq_positions
#check @TheoremT.Continuum.configurationRotation
#check @TheoremT.Continuum.position_configurationRotation
#check @TheoremT.Continuum.coulombPotential_configurationRotation
#check @TheoremT.Continuum.configurationRotation_permuteSpace
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.rotateConfigurationLinear
#print axioms TheoremT.Continuum.position_rotateConfigurationLinear
#print axioms TheoremT.Continuum.configuration_norm_sq_positions
#print axioms TheoremT.Continuum.configurationRotation
#print axioms TheoremT.Continuum.position_configurationRotation
#print axioms TheoremT.Continuum.coulombPotential_configurationRotation
#print axioms TheoremT.Continuum.configurationRotation_permuteSpace
