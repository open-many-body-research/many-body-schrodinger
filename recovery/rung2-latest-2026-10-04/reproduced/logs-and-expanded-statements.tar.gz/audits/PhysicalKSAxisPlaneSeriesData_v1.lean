import PhysicalKSAxisPlaneSeriesData_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.physicalKSAxisPlanePolynomialA
#check @TheoremT.Continuum.physicalKSAxisPlanePolynomialB
#check @TheoremT.Continuum.physicalKSAxisPlaneSeries_data
#check @TheoremT.Continuum.nuclearKSPhysicalAxisPlaneSeries_data
#check @TheoremT.Continuum.pairKSPhysicalAxisPlaneSeries_data
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.physicalKSAxisPlanePolynomialA
#print axioms TheoremT.Continuum.physicalKSAxisPlanePolynomialB
#print axioms TheoremT.Continuum.physicalKSAxisPlaneSeries_data
#print axioms TheoremT.Continuum.nuclearKSPhysicalAxisPlaneSeries_data
#print axioms TheoremT.Continuum.pairKSPhysicalAxisPlaneSeries_data
