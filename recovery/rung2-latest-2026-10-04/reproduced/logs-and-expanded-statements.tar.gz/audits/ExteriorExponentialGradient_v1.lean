import ExteriorExponentialGradient_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.exteriorWeightError
#check @TheoremT.Continuum.cutoff_derivative_times_weight_abs_le
#check @TheoremT.Continuum.exteriorExpWeight_gradient_bound
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.exteriorWeightError
#print axioms TheoremT.Continuum.cutoff_derivative_times_weight_abs_le
#print axioms TheoremT.Continuum.exteriorExpWeight_gradient_bound
