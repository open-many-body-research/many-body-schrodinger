import ExponentialL2Tail_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.exteriorL2
#check @TheoremT.Continuum.exteriorL2_ae
#check @TheoremT.Continuum.exponential_L2_tail_bound
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.exteriorL2
#print axioms TheoremT.Continuum.exteriorL2_ae
#print axioms TheoremT.Continuum.exponential_L2_tail_bound
