import ExponentialWeightComparison_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.physical_exponential_memLp_of_smooth
#check @TheoremT.Continuum.smooth_exponential_memLp_of_physical
#check @TheoremT.Continuum.boundedExpWeight_mul_norm_le
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.physical_exponential_memLp_of_smooth
#print axioms TheoremT.Continuum.smooth_exponential_memLp_of_physical
#print axioms TheoremT.Continuum.boundedExpWeight_mul_norm_le
