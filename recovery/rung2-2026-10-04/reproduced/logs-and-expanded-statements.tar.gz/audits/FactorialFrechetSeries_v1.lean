import FactorialFrechetSeries_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.factorialFrechetSeries
#check @TheoremT.Continuum.factorialFrechetSeries_apply
#check @TheoremT.Continuum.factorialFrechetSeries_norm_le
#check @TheoremT.Continuum.factorialFrechetSeries_radius_ge
#check @TheoremT.Continuum.factorialFrechetSeries_summable_norm
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.factorialFrechetSeries
#print axioms TheoremT.Continuum.factorialFrechetSeries_apply
#print axioms TheoremT.Continuum.factorialFrechetSeries_norm_le
#print axioms TheoremT.Continuum.factorialFrechetSeries_radius_ge
#print axioms TheoremT.Continuum.factorialFrechetSeries_summable_norm
