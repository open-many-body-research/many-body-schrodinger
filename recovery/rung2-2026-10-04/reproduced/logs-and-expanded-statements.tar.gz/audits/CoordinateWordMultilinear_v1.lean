import CoordinateWordMultilinear_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.coordinateWordMultilinear
#check @TheoremT.Continuum.coordinateWordMultilinear_apply
#check @TheoremT.Continuum.coordinateWordMultilinear_norm_le
#check @TheoremT.Continuum.coordinateWordMultilinear_diagonal
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.coordinateWordMultilinear
#print axioms TheoremT.Continuum.coordinateWordMultilinear_apply
#print axioms TheoremT.Continuum.coordinateWordMultilinear_norm_le
#print axioms TheoremT.Continuum.coordinateWordMultilinear_diagonal
