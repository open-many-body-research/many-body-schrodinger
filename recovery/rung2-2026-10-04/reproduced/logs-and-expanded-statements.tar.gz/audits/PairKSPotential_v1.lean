import PairKSPotential_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.pairKSPotential
#check @TheoremT.Continuum.pairKSCoefficientPatch
#check @TheoremT.Continuum.pairKSPotential_eq_coulomb_scaled
#check @TheoremT.Continuum.pairKSPotential_on_zero
#check @TheoremT.Continuum.pairKSCoefficientPatch_off_zero_collisionFree
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.pairKSPotential
#print axioms TheoremT.Continuum.pairKSCoefficientPatch
#print axioms TheoremT.Continuum.pairKSPotential_eq_coulomb_scaled
#print axioms TheoremT.Continuum.pairKSPotential_on_zero
#print axioms TheoremT.Continuum.pairKSCoefficientPatch_off_zero_collisionFree
