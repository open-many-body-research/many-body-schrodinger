import PhysicalSpinCoordinateH12Reserve_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.WeakGrushin.ProductCoordinateWeakHk.mono_budget
#check @TheoremT.Continuum.WeakGrushin.SpinPhysicalH12Reserve
#check @TheoremT.Continuum.WeakGrushin.spinPhysicalH12Reserve_of_coordinate
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.WeakGrushin.ProductCoordinateWeakHk.mono_budget
#print axioms TheoremT.Continuum.WeakGrushin.SpinPhysicalH12Reserve
#print axioms TheoremT.Continuum.WeakGrushin.spinPhysicalH12Reserve_of_coordinate
