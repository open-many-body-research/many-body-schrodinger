import SmoothCutoffRescaleGeometry_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.cutoffRescaleMap
#check @TheoremT.Continuum.cutoffRescale
#check @TheoremT.Continuum.cutoffRescaleMap_contDiff
#check @TheoremT.Continuum.cutoffRescale_contDiff
#check @TheoremT.Continuum.cutoffRescaleMap_inverse_left
#check @TheoremT.Continuum.cutoffRescaleMap_inverse_right
#check @TheoremT.Continuum.cutoffRescaleHomeomorph
#check @TheoremT.Continuum.cutoffRescale_tsupport_preimage
#check @TheoremT.Continuum.cutoffRescale_tsupport_image
#check @TheoremT.Continuum.cutoffRescale_hasCompactSupport
#check @TheoremT.Continuum.cutoffRescale_plateau_image
#check @TheoremT.Continuum.cutoffRescale_tsupport_closedBall
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.cutoffRescaleMap
#print axioms TheoremT.Continuum.cutoffRescale
#print axioms TheoremT.Continuum.cutoffRescaleMap_contDiff
#print axioms TheoremT.Continuum.cutoffRescale_contDiff
#print axioms TheoremT.Continuum.cutoffRescaleMap_inverse_left
#print axioms TheoremT.Continuum.cutoffRescaleMap_inverse_right
#print axioms TheoremT.Continuum.cutoffRescaleHomeomorph
#print axioms TheoremT.Continuum.cutoffRescale_tsupport_preimage
#print axioms TheoremT.Continuum.cutoffRescale_tsupport_image
#print axioms TheoremT.Continuum.cutoffRescale_hasCompactSupport
#print axioms TheoremT.Continuum.cutoffRescale_plateau_image
#print axioms TheoremT.Continuum.cutoffRescale_tsupport_closedBall
