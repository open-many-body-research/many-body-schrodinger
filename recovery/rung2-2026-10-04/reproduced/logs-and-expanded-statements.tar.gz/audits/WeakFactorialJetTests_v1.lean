import WeakFactorialJetTests_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.WeakGrushin.weakCoordinateJet_directional
#check @TheoremT.Continuum.WeakGrushin.weakCoordinateJet_test_identity
#check @TheoremT.Continuum.WeakGrushin.weakCoordinateJet_tests_integrable
#check @TheoremT.Continuum.WeakGrushin.weakFactorialJet_tests
#check @TheoremT.Continuum.WeakGrushin.weakFactorialJet_ae_eq_local_of_tests
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.WeakGrushin.weakCoordinateJet_directional
#print axioms TheoremT.Continuum.WeakGrushin.weakCoordinateJet_test_identity
#print axioms TheoremT.Continuum.WeakGrushin.weakCoordinateJet_tests_integrable
#print axioms TheoremT.Continuum.WeakGrushin.weakFactorialJet_tests
#print axioms TheoremT.Continuum.WeakGrushin.weakFactorialJet_ae_eq_local_of_tests
