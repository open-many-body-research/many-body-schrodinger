import KSFinitePhysicalPolynomialDescent_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.ksPolynomialDescentA
#check @TheoremT.Continuum.ksPolynomialDescentB
#check @TheoremT.Continuum.ks_balanced_support_half_degree
#check @TheoremT.Continuum.ks_balanced_polynomial_descent_homogeneous
#check @TheoremT.Continuum.ks_balanced_polynomial_physical_descent
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.ksPolynomialDescentA
#print axioms TheoremT.Continuum.ksPolynomialDescentB
#print axioms TheoremT.Continuum.ks_balanced_support_half_degree
#print axioms TheoremT.Continuum.ks_balanced_polynomial_descent_homogeneous
#print axioms TheoremT.Continuum.ks_balanced_polynomial_physical_descent
