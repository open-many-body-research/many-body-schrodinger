import LocalWeakYLaplacianRecovery_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.WeakGrushin.LocalSpectatorD.second_test
#check @TheoremT.Continuum.WeakGrushin.local_y_to_product_laplacian_tests
#check @TheoremT.Continuum.WeakGrushin.local_y_laplacian_h2_of_spectator_jets
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.WeakGrushin.LocalSpectatorD.second_test
#print axioms TheoremT.Continuum.WeakGrushin.local_y_to_product_laplacian_tests
#print axioms TheoremT.Continuum.WeakGrushin.local_y_laplacian_h2_of_spectator_jets
