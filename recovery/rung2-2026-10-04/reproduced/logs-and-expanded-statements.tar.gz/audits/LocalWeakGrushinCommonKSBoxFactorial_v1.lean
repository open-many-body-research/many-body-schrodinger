import LocalWeakGrushinCommonKSBoxFactorial_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.WeakGrushin.commonKSBoxFactorialConstant
#check @TheoremT.Continuum.WeakGrushin.fixedBoxFactorialConstant_one_le
#check @TheoremT.Continuum.WeakGrushin.fixedBoxFactorialConstant_le_common
#check @TheoremT.Continuum.WeakGrushin.local_weak_grushin_common_KS_box_factorial
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.WeakGrushin.commonKSBoxFactorialConstant
#print axioms TheoremT.Continuum.WeakGrushin.fixedBoxFactorialConstant_one_le
#print axioms TheoremT.Continuum.WeakGrushin.fixedBoxFactorialConstant_le_common
#print axioms TheoremT.Continuum.WeakGrushin.local_weak_grushin_common_KS_box_factorial
