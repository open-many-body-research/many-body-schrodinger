import SpectatorIterationBudget_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.WeakGrushin.spectatorIterationJ
#check @TheoremT.Continuum.WeakGrushin.spectatorIterationNext
#check @TheoremT.Continuum.WeakGrushin.spectatorIterationJ_nonneg
#check @TheoremT.Continuum.WeakGrushin.spectatorIterationBudget_bounds
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.WeakGrushin.spectatorIterationJ
#print axioms TheoremT.Continuum.WeakGrushin.spectatorIterationNext
#print axioms TheoremT.Continuum.WeakGrushin.spectatorIterationJ_nonneg
#print axioms TheoremT.Continuum.WeakGrushin.spectatorIterationBudget_bounds
