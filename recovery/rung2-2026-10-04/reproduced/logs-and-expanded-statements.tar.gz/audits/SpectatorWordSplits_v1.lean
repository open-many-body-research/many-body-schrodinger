import SpectatorWordSplits_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.WeakGrushin.spectatorWordSplits
#check @TheoremT.Continuum.WeakGrushin.spectatorWordProperSplits
#check @TheoremT.Continuum.WeakGrushin.spectatorWordSplits_eq_proper_append
#check @TheoremT.Continuum.WeakGrushin.spectatorWordSplits_length
#check @TheoremT.Continuum.WeakGrushin.spectatorWordProperSplits_length
#check @TheoremT.Continuum.WeakGrushin.spectatorWordSplits_length_sum
#check @TheoremT.Continuum.WeakGrushin.spectatorWordProperSplits_strict
#check @TheoremT.Continuum.WeakGrushin.spectatorWordDeriv
#check @TheoremT.Continuum.WeakGrushin.spectatorWordDeriv_contDiffOn
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.WeakGrushin.spectatorWordSplits
#print axioms TheoremT.Continuum.WeakGrushin.spectatorWordProperSplits
#print axioms TheoremT.Continuum.WeakGrushin.spectatorWordSplits_eq_proper_append
#print axioms TheoremT.Continuum.WeakGrushin.spectatorWordSplits_length
#print axioms TheoremT.Continuum.WeakGrushin.spectatorWordProperSplits_length
#print axioms TheoremT.Continuum.WeakGrushin.spectatorWordSplits_length_sum
#print axioms TheoremT.Continuum.WeakGrushin.spectatorWordProperSplits_strict
#print axioms TheoremT.Continuum.WeakGrushin.spectatorWordDeriv
#print axioms TheoremT.Continuum.WeakGrushin.spectatorWordDeriv_contDiffOn
