import GrushinFactorialOuterL2_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.WeakGrushin.factorialYMonomial
#check @TheoremT.Continuum.WeakGrushin.factorialYMonomial_square
#check @TheoremT.Continuum.WeakGrushin.factorialYMonomial_zero
#check @TheoremT.Continuum.WeakGrushin.FactorialOuterL2Rep
#check @TheoremT.Continuum.WeakGrushin.factorial_outer_square_row_L2
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.WeakGrushin.factorialYMonomial
#print axioms TheoremT.Continuum.WeakGrushin.factorialYMonomial_square
#print axioms TheoremT.Continuum.WeakGrushin.factorialYMonomial_zero
#print axioms TheoremT.Continuum.WeakGrushin.FactorialOuterL2Rep
#print axioms TheoremT.Continuum.WeakGrushin.factorial_outer_square_row_L2
