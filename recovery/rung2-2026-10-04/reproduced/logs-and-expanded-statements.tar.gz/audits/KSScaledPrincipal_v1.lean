import KSScaledPrincipal_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.ksScaledPrincipal
#check @TheoremT.Continuum.ksScaledRealPrincipal
#check @TheoremT.Continuum.ksScaledPrincipal_four
#check @TheoremT.Continuum.ksScaledRealPrincipal_four
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.ksScaledPrincipal
#print axioms TheoremT.Continuum.ksScaledRealPrincipal
#print axioms TheoremT.Continuum.ksScaledPrincipal_four
#print axioms TheoremT.Continuum.ksScaledRealPrincipal_four
