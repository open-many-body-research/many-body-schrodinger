import KSFixedChartPatch_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.ksFixedChartRegion
#check @TheoremT.Continuum.ksFixedChartRegion_mem_iff
#check @TheoremT.Continuum.ksFixedChartRegion_isCompact
#check @TheoremT.Continuum.ksFixedChartRegion_center_mem
#check @TheoremT.Continuum.ksFixedChartRegion_spectator_norm
#check @TheoremT.Continuum.ksFixedChartRegion_ks_radius
#check @TheoremT.Continuum.ksFixedChartRegion_pair_nuclear_radii
#check @TheoremT.Continuum.ksFixedChartRegion_subset_pair_patch
#check @TheoremT.Continuum.nuclearKSLift_zero_other_position
#check @TheoremT.Continuum.ksFixedChartRegion_nuclear_other_radius
#check @TheoremT.Continuum.ksFixedChartRegion_nuclear_pair_radius
#check @TheoremT.Continuum.ksFixedChartRegion_subset_nuclear_patch
#check @TheoremT.Continuum.ksFixedChartRegion_image_norms
#check @TheoremT.Continuum.pairKSLift_zero_fiber_collision
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.ksFixedChartRegion
#print axioms TheoremT.Continuum.ksFixedChartRegion_mem_iff
#print axioms TheoremT.Continuum.ksFixedChartRegion_isCompact
#print axioms TheoremT.Continuum.ksFixedChartRegion_center_mem
#print axioms TheoremT.Continuum.ksFixedChartRegion_spectator_norm
#print axioms TheoremT.Continuum.ksFixedChartRegion_ks_radius
#print axioms TheoremT.Continuum.ksFixedChartRegion_pair_nuclear_radii
#print axioms TheoremT.Continuum.ksFixedChartRegion_subset_pair_patch
#print axioms TheoremT.Continuum.nuclearKSLift_zero_other_position
#print axioms TheoremT.Continuum.ksFixedChartRegion_nuclear_other_radius
#print axioms TheoremT.Continuum.ksFixedChartRegion_nuclear_pair_radius
#print axioms TheoremT.Continuum.ksFixedChartRegion_subset_nuclear_patch
#print axioms TheoremT.Continuum.ksFixedChartRegion_image_norms
#print axioms TheoremT.Continuum.pairKSLift_zero_fiber_collision
