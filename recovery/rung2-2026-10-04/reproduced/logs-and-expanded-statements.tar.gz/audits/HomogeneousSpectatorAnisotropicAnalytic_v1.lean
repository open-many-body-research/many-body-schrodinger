import HomogeneousSpectatorAnisotropicAnalytic_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.exists_positive_larger_geometric_radius
#check @TheoremT.Continuum.homogeneous_spectator_sum_analytic_anisotropic
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.exists_positive_larger_geometric_radius
#print axioms TheoremT.Continuum.homogeneous_spectator_sum_analytic_anisotropic
