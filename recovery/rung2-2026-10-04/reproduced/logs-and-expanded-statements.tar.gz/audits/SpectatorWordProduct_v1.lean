import SpectatorWordProduct_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.WeakGrushin.spectatorWordProduct
#check @TheoremT.Continuum.WeakGrushin.spectatorWordCommutator
#check @TheoremT.Continuum.WeakGrushin.spectatorWordProduct_eq_commutator_add
#check @TheoremT.Continuum.WeakGrushin.spectatorWordProduct_cons
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.WeakGrushin.spectatorWordProduct
#print axioms TheoremT.Continuum.WeakGrushin.spectatorWordCommutator
#print axioms TheoremT.Continuum.WeakGrushin.spectatorWordProduct_eq_commutator_add
#print axioms TheoremT.Continuum.WeakGrushin.spectatorWordProduct_cons
