import GrushinH12CutoffData_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.WeakGrushin.h12InnerCutoff
#check @TheoremT.Continuum.WeakGrushin.h12EnergyCutoff
#check @TheoremT.Continuum.WeakGrushin.h12CutoffWeightBound
#check @TheoremT.Continuum.WeakGrushin.h12CutoffScalarBound
#check @TheoremT.Continuum.WeakGrushin.h12CutoffWeightBound_nonneg
#check @TheoremT.Continuum.WeakGrushin.h12_cutoff_geometry
#check @TheoremT.Continuum.WeakGrushin.h12_cutoff_value_bounds
#check @TheoremT.Continuum.WeakGrushin.h12_cutoff_coefficient_bounds
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.WeakGrushin.h12InnerCutoff
#print axioms TheoremT.Continuum.WeakGrushin.h12EnergyCutoff
#print axioms TheoremT.Continuum.WeakGrushin.h12CutoffWeightBound
#print axioms TheoremT.Continuum.WeakGrushin.h12CutoffScalarBound
#print axioms TheoremT.Continuum.WeakGrushin.h12CutoffWeightBound_nonneg
#print axioms TheoremT.Continuum.WeakGrushin.h12_cutoff_geometry
#print axioms TheoremT.Continuum.WeakGrushin.h12_cutoff_value_bounds
#print axioms TheoremT.Continuum.WeakGrushin.h12_cutoff_coefficient_bounds
