import MixedWordFDeriv_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.WeakGrushin.productCoordinateDirection_norm
#check @TheoremT.Continuum.WeakGrushin.coordinateWordDeriv_of_tWord
#check @TheoremT.Continuum.WeakGrushin.mixedWordDeriv_eq_coordinateWord
#check @TheoremT.Continuum.WeakGrushin.mixedWordDeriv_abs_le_iteratedFDeriv
#check @TheoremT.Continuum.WeakGrushin.mixedWordDeriv_finite_bound
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.WeakGrushin.productCoordinateDirection_norm
#print axioms TheoremT.Continuum.WeakGrushin.coordinateWordDeriv_of_tWord
#print axioms TheoremT.Continuum.WeakGrushin.mixedWordDeriv_eq_coordinateWord
#print axioms TheoremT.Continuum.WeakGrushin.mixedWordDeriv_abs_le_iteratedFDeriv
#print axioms TheoremT.Continuum.WeakGrushin.mixedWordDeriv_finite_bound
