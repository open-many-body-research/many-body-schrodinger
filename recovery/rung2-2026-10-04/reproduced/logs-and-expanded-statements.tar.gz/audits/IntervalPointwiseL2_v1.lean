import IntervalPointwiseL2_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.finite_measure_integral_norm_le_sqrt
#check @TheoremT.Continuum.interval_integral_norm_le_sqrt
#check @TheoremT.Continuum.interval_pointwise_norm_le_L2
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.finite_measure_integral_norm_le_sqrt
#print axioms TheoremT.Continuum.interval_integral_norm_le_sqrt
#print axioms TheoremT.Continuum.interval_pointwise_norm_le_L2
