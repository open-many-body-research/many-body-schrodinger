import WeakFactorialJetSupport_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.WeakGrushin.weakCoordinateJet_closed_support
#check @TheoremT.Continuum.WeakGrushin.weakFactorialJet_closed_support
#check @TheoremT.Continuum.WeakGrushin.weakFactorialJet_ae_eq_of_local_tests_support
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.WeakGrushin.weakCoordinateJet_closed_support
#print axioms TheoremT.Continuum.WeakGrushin.weakFactorialJet_closed_support
#print axioms TheoremT.Continuum.WeakGrushin.weakFactorialJet_ae_eq_of_local_tests_support
