import ProductCompactAllWeakWords_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.product_compact_local_all_weak_words_global
#check @TheoremT.Continuum.product_compact_cutoff_all_weak_word_family
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.product_compact_local_all_weak_words_global
#print axioms TheoremT.Continuum.product_compact_cutoff_all_weak_word_family
