import MixedYIterationBudget_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.WeakGrushin.mixedYSourceBudget
#check @TheoremT.Continuum.WeakGrushin.mixedYIterationNext
#check @TheoremT.Continuum.WeakGrushin.mixedYSourceBudget_nonneg
#check @TheoremT.Continuum.WeakGrushin.mixedYIterationNext_ge
#check @TheoremT.Continuum.WeakGrushin.mixedYIterationNext_nonneg
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.WeakGrushin.mixedYSourceBudget
#print axioms TheoremT.Continuum.WeakGrushin.mixedYIterationNext
#print axioms TheoremT.Continuum.WeakGrushin.mixedYSourceBudget_nonneg
#print axioms TheoremT.Continuum.WeakGrushin.mixedYIterationNext_ge
#print axioms TheoremT.Continuum.WeakGrushin.mixedYIterationNext_nonneg
