import KSPotentialEnergyAffine_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.nuclearKSPotential_scaled_energy_affine_fun
#check @TheoremT.Continuum.pairKSPotential_scaled_energy_affine_fun
#check @TheoremT.Continuum.nuclearKS_energy_coefficient_contDiff
#check @TheoremT.Continuum.pairKS_energy_coefficient_contDiff
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.nuclearKSPotential_scaled_energy_affine_fun
#print axioms TheoremT.Continuum.pairKSPotential_scaled_energy_affine_fun
#print axioms TheoremT.Continuum.nuclearKS_energy_coefficient_contDiff
#print axioms TheoremT.Continuum.pairKS_energy_coefficient_contDiff
