import GrushinFactorialPrincipalIndexSplit_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.WeakGrushin.factorial_multiindex_sum_sub
#check @TheoremT.Continuum.WeakGrushin.factorial_multiindex_single_le
#check @TheoremT.Continuum.WeakGrushin.factorial_multiindex_double_single
#check @TheoremT.Continuum.WeakGrushin.factorial_principal_one_hit_split
#check @TheoremT.Continuum.WeakGrushin.factorial_principal_two_hit_split
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.WeakGrushin.factorial_multiindex_sum_sub
#print axioms TheoremT.Continuum.WeakGrushin.factorial_multiindex_single_le
#print axioms TheoremT.Continuum.WeakGrushin.factorial_multiindex_double_single
#print axioms TheoremT.Continuum.WeakGrushin.factorial_principal_one_hit_split
#print axioms TheoremT.Continuum.WeakGrushin.factorial_principal_two_hit_split
