import ProductLocalDiagonalWeakH2_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.ProductLocalWeakDirectional.second_same_test
#check @TheoremT.Continuum.product_local_weakH2_of_diagonal_jets
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.ProductLocalWeakDirectional.second_same_test
#print axioms TheoremT.Continuum.product_local_weakH2_of_diagonal_jets
