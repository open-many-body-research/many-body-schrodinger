import KSBalancedDescentPolynomial_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.ksDescentQuadraticPolynomial
#check @TheoremT.Continuum.ksDescentQuadraticPolynomial_homogeneous
#check @TheoremT.Continuum.ksDescentQuadraticPolynomial_eval
#check @TheoremT.Continuum.ksBalancedDescentPolynomial
#check @TheoremT.Continuum.ksBalancedDescentPolynomial_homogeneous
#check @TheoremT.Continuum.ksBalancedDescentPolynomial_eval
#check @TheoremT.Continuum.ksSpinor_balanced_descent_polynomial
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.ksDescentQuadraticPolynomial
#print axioms TheoremT.Continuum.ksDescentQuadraticPolynomial_homogeneous
#print axioms TheoremT.Continuum.ksDescentQuadraticPolynomial_eval
#print axioms TheoremT.Continuum.ksBalancedDescentPolynomial
#print axioms TheoremT.Continuum.ksBalancedDescentPolynomial_homogeneous
#print axioms TheoremT.Continuum.ksBalancedDescentPolynomial_eval
#print axioms TheoremT.Continuum.ksSpinor_balanced_descent_polynomial
