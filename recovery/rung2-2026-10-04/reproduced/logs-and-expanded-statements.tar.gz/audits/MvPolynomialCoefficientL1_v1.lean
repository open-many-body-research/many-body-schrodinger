import MvPolynomialCoefficientL1_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.polynomialCoeffL1
#check @TheoremT.Continuum.polynomialCoeffL1_eq_sum
#check @TheoremT.Continuum.polynomialCoeffL1_nonneg
#check @TheoremT.Continuum.polynomialCoeffL1_eq_sum_of_support_subset
#check @TheoremT.Continuum.polynomialCoeffL1_zero
#check @TheoremT.Continuum.polynomialCoeffL1_monomial
#check @TheoremT.Continuum.polynomialCoeffL1_C
#check @TheoremT.Continuum.polynomialCoeffL1_one
#check @TheoremT.Continuum.polynomialCoeffL1_X
#check @TheoremT.Continuum.polynomialCoeffL1_add
#check @TheoremT.Continuum.polynomialCoeffL1_sum
#check @TheoremT.Continuum.polynomialCoeffL1_mul
#check @TheoremT.Continuum.polynomialCoeffL1_pow
#check @TheoremT.Continuum.polynomialCoeffL1_prod
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.polynomialCoeffL1
#print axioms TheoremT.Continuum.polynomialCoeffL1_eq_sum
#print axioms TheoremT.Continuum.polynomialCoeffL1_nonneg
#print axioms TheoremT.Continuum.polynomialCoeffL1_eq_sum_of_support_subset
#print axioms TheoremT.Continuum.polynomialCoeffL1_zero
#print axioms TheoremT.Continuum.polynomialCoeffL1_monomial
#print axioms TheoremT.Continuum.polynomialCoeffL1_C
#print axioms TheoremT.Continuum.polynomialCoeffL1_one
#print axioms TheoremT.Continuum.polynomialCoeffL1_X
#print axioms TheoremT.Continuum.polynomialCoeffL1_add
#print axioms TheoremT.Continuum.polynomialCoeffL1_sum
#print axioms TheoremT.Continuum.polynomialCoeffL1_mul
#print axioms TheoremT.Continuum.polynomialCoeffL1_pow
#print axioms TheoremT.Continuum.polynomialCoeffL1_prod
