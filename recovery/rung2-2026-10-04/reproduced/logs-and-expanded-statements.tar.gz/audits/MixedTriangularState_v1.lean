import MixedTriangularState_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.WeakGrushin.MixedTriangularState
#check @TheoremT.Continuum.WeakGrushin.MixedTriangularState.restrict
#check @TheoremT.Continuum.WeakGrushin.spectatorFiniteState_to_mixedTriangularState
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.WeakGrushin.MixedTriangularState
#print axioms TheoremT.Continuum.WeakGrushin.MixedTriangularState.restrict
#print axioms TheoremT.Continuum.WeakGrushin.spectatorFiniteState_to_mixedTriangularState
