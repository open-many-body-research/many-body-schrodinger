import PhysicalH12ConcreteStepGeometry_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.WeakGrushin.physicalH12ConcreteBox
#check @TheoremT.Continuum.WeakGrushin.physicalH12ConcreteInnerCutoff
#check @TheoremT.Continuum.WeakGrushin.physicalH12ConcreteEnergyCutoff
#check @TheoremT.Continuum.WeakGrushin.physicalH12ConcreteBox_isOpen
#check @TheoremT.Continuum.WeakGrushin.physicalH12ConcreteBox_measurableSet
#check @TheoremT.Continuum.WeakGrushin.physicalH12ConcreteBox_antitone
#check @TheoremT.Continuum.WeakGrushin.physicalH12ConcreteBox_zero
#check @TheoremT.Continuum.WeakGrushin.physicalH12ConcreteBox_34
#check @TheoremT.Continuum.WeakGrushin.physical_h12_concrete_step_geometry
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.WeakGrushin.physicalH12ConcreteBox
#print axioms TheoremT.Continuum.WeakGrushin.physicalH12ConcreteInnerCutoff
#print axioms TheoremT.Continuum.WeakGrushin.physicalH12ConcreteEnergyCutoff
#print axioms TheoremT.Continuum.WeakGrushin.physicalH12ConcreteBox_isOpen
#print axioms TheoremT.Continuum.WeakGrushin.physicalH12ConcreteBox_measurableSet
#print axioms TheoremT.Continuum.WeakGrushin.physicalH12ConcreteBox_antitone
#print axioms TheoremT.Continuum.WeakGrushin.physicalH12ConcreteBox_zero
#print axioms TheoremT.Continuum.WeakGrushin.physicalH12ConcreteBox_34
#print axioms TheoremT.Continuum.WeakGrushin.physical_h12_concrete_step_geometry
