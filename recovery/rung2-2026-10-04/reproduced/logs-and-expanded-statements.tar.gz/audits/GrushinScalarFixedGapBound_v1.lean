import GrushinScalarFixedGapBound_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.grushin_scalar_fixed_gap_grid_bound
#check @TheoremT.Continuum.grushin_scalar_fixed_gap_bound
#check @TheoremT.Continuum.grushin_scalar_fixed_gap_zero
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.grushin_scalar_fixed_gap_grid_bound
#print axioms TheoremT.Continuum.grushin_scalar_fixed_gap_bound
#print axioms TheoremT.Continuum.grushin_scalar_fixed_gap_zero
