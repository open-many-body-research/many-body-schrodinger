import TensorBoxUniformLimit_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.tensor_box_sqrt_integral_eq_Lp_norm
#check @TheoremT.Continuum.tensor_box7_uniformCauchy_of_L2_Cauchy
#check @TheoremT.Continuum.tensor_box7_continuous_uniform_limit_of_L2_Cauchy
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.tensor_box_sqrt_integral_eq_Lp_norm
#print axioms TheoremT.Continuum.tensor_box7_uniformCauchy_of_L2_Cauchy
#print axioms TheoremT.Continuum.tensor_box7_continuous_uniform_limit_of_L2_Cauchy
