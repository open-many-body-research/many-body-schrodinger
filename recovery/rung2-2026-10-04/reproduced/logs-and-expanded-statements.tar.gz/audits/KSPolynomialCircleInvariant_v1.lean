import KSPolynomialCircleInvariant_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.ksPolynomialCircleAction
#check @TheoremT.Continuum.ksPolynomialCircleAction_eq_diagonal
#check @TheoremT.Continuum.ksPolynomialCircleAction_coeff
#check @TheoremT.Continuum.ksPolynomialCircleInvariant_balanced_support
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.ksPolynomialCircleAction
#print axioms TheoremT.Continuum.ksPolynomialCircleAction_eq_diagonal
#print axioms TheoremT.Continuum.ksPolynomialCircleAction_coeff
#print axioms TheoremT.Continuum.ksPolynomialCircleInvariant_balanced_support
