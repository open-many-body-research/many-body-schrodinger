import GrushinFactorialRawCommutatorL2_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.WeakGrushin.rawGrushinCutoffError
#check @TheoremT.Continuum.WeakGrushin.rawGrushinCutoffError_eq_combined
#check @TheoremT.Continuum.WeakGrushin.lp_four_blocks_ae
#check @TheoremT.Continuum.WeakGrushin.lp_four_blocks_norm
#check @TheoremT.Continuum.WeakGrushin.factorial_raw_cutoff_error_L2
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.WeakGrushin.rawGrushinCutoffError
#print axioms TheoremT.Continuum.WeakGrushin.rawGrushinCutoffError_eq_combined
#print axioms TheoremT.Continuum.WeakGrushin.lp_four_blocks_ae
#print axioms TheoremT.Continuum.WeakGrushin.lp_four_blocks_norm
#print axioms TheoremT.Continuum.WeakGrushin.factorial_raw_cutoff_error_L2
