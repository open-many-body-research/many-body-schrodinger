import ProductCoordinateWeakHk_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.WeakGrushin.coordinateYWord
#check @TheoremT.Continuum.WeakGrushin.coordinateTWord
#check @TheoremT.Continuum.WeakGrushin.productCoordinateDirection
#check @TheoremT.Continuum.WeakGrushin.coordinateWord_length
#check @TheoremT.Continuum.WeakGrushin.ProductCoordinateWeakHk
#check @TheoremT.Continuum.WeakGrushin.mixedTriangularState_coordinateWeakHk
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.WeakGrushin.coordinateYWord
#print axioms TheoremT.Continuum.WeakGrushin.coordinateTWord
#print axioms TheoremT.Continuum.WeakGrushin.productCoordinateDirection
#print axioms TheoremT.Continuum.WeakGrushin.coordinateWord_length
#print axioms TheoremT.Continuum.WeakGrushin.ProductCoordinateWeakHk
#print axioms TheoremT.Continuum.WeakGrushin.mixedTriangularState_coordinateWeakHk
