import CoulombSpinKSScaledAmplitude_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.finite_family_locallyLipschitz_origin_ball
#check @TheoremT.Continuum.coulomb_spin_KS_scaled_amplitude_representative
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.finite_family_locallyLipschitz_origin_ball
#print axioms TheoremT.Continuum.coulomb_spin_KS_scaled_amplitude_representative
