import LocalProductDirectionalWeakAlgebra_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.ProductLocalWeakDirectional
#check @TheoremT.Continuum.ProductLocalWeakDirectional.of_global
#check @TheoremT.Continuum.ProductLocalWeakDirectional.mono
#check @TheoremT.Continuum.ProductLocalWeakDirectional.test_integrable
#check @TheoremT.Continuum.ProductLocalWeakDirectional.swap
#check @TheoremT.Continuum.ProductLocalWeakDirectional.smooth_smul
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.ProductLocalWeakDirectional
#print axioms TheoremT.Continuum.ProductLocalWeakDirectional.of_global
#print axioms TheoremT.Continuum.ProductLocalWeakDirectional.mono
#print axioms TheoremT.Continuum.ProductLocalWeakDirectional.test_integrable
#print axioms TheoremT.Continuum.ProductLocalWeakDirectional.swap
#print axioms TheoremT.Continuum.ProductLocalWeakDirectional.smooth_smul
