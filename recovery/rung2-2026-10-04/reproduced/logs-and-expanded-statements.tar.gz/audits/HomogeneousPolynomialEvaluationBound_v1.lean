import HomogeneousPolynomialEvaluationBound_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.complexClosedPolydisc
#check @TheoremT.Continuum.complexOpenPolydisc
#check @TheoremT.Continuum.homogeneous_polynomial_eval_norm_bound
#check @TheoremT.Continuum.homogeneous_polynomial_eval_norm_geometric
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.complexClosedPolydisc
#print axioms TheoremT.Continuum.complexOpenPolydisc
#print axioms TheoremT.Continuum.homogeneous_polynomial_eval_norm_bound
#print axioms TheoremT.Continuum.homogeneous_polynomial_eval_norm_geometric
