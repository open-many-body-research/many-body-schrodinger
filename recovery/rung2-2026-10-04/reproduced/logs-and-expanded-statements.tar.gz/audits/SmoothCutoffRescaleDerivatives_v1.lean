import SmoothCutoffRescaleDerivatives_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.cutoffRescale_first
#check @TheoremT.Continuum.cutoffRescale_second
#check @TheoremT.Continuum.smooth_directional_second_eq_fderiv_fderiv
#check @TheoremT.Continuum.cutoffRescale_first_bound
#check @TheoremT.Continuum.cutoffRescale_second_bound
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.cutoffRescale_first
#print axioms TheoremT.Continuum.cutoffRescale_second
#print axioms TheoremT.Continuum.smooth_directional_second_eq_fderiv_fderiv
#print axioms TheoremT.Continuum.cutoffRescale_first_bound
#print axioms TheoremT.Continuum.cutoffRescale_second_bound
