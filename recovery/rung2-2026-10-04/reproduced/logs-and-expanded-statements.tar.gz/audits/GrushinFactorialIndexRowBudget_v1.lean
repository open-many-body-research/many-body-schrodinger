import GrushinFactorialIndexRowBudget_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.WeakGrushin.FactorialRawJetFamily
#check @TheoremT.Continuum.WeakGrushin.FactorialShiftedOuterL2Rep
#check @TheoremT.Continuum.WeakGrushin.factorial_multiindex_sub_add
#check @TheoremT.Continuum.WeakGrushin.factorial_zero_row_budget
#check @TheoremT.Continuum.WeakGrushin.factorial_first_y_row_budget
#check @TheoremT.Continuum.WeakGrushin.factorial_first_t_row_budget
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.WeakGrushin.FactorialRawJetFamily
#print axioms TheoremT.Continuum.WeakGrushin.FactorialShiftedOuterL2Rep
#print axioms TheoremT.Continuum.WeakGrushin.factorial_multiindex_sub_add
#print axioms TheoremT.Continuum.WeakGrushin.factorial_zero_row_budget
#print axioms TheoremT.Continuum.WeakGrushin.factorial_first_y_row_budget
#print axioms TheoremT.Continuum.WeakGrushin.factorial_first_t_row_budget
