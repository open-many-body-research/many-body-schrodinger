import CoordinateMultiIndexWord_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.sevenCoordinateEquiv
#check @TheoremT.Continuum.coordinateMultiIndexWord
#check @TheoremT.Continuum.coordinateWordCount
#check @TheoremT.Continuum.coordinateMultiIndexWord_length
#check @TheoremT.Continuum.coordinateMultiIndexWord_count
#check @TheoremT.Continuum.coordinateMultiIndexWord_count_y
#check @TheoremT.Continuum.coordinateMultiIndexWord_count_t
#check @TheoremT.Continuum.coordinateMultiIndexWord_injective
#check @TheoremT.Continuum.h12CoordinateWord
#check @TheoremT.Continuum.h12ZeroMultiIndex
#check @TheoremT.Continuum.h12CoordinateWord_length
#check @TheoremT.Continuum.h12CoordinateWord_length_le
#check @TheoremT.Continuum.h12CoordinateWord_zero
#check @TheoremT.Continuum.h12CoordinateWord_injective
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.sevenCoordinateEquiv
#print axioms TheoremT.Continuum.coordinateMultiIndexWord
#print axioms TheoremT.Continuum.coordinateWordCount
#print axioms TheoremT.Continuum.coordinateMultiIndexWord_length
#print axioms TheoremT.Continuum.coordinateMultiIndexWord_count
#print axioms TheoremT.Continuum.coordinateMultiIndexWord_count_y
#print axioms TheoremT.Continuum.coordinateMultiIndexWord_count_t
#print axioms TheoremT.Continuum.coordinateMultiIndexWord_injective
#print axioms TheoremT.Continuum.h12CoordinateWord
#print axioms TheoremT.Continuum.h12ZeroMultiIndex
#print axioms TheoremT.Continuum.h12CoordinateWord_length
#print axioms TheoremT.Continuum.h12CoordinateWord_length_le
#print axioms TheoremT.Continuum.h12CoordinateWord_zero
#print axioms TheoremT.Continuum.h12CoordinateWord_injective
