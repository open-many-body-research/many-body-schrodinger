import GrushinScalarGridNormalization_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.grushinGridNorm
#check @TheoremT.Continuum.grushin_grid_time_bounds
#check @TheoremT.Continuum.grushin_gridNorm_nonneg
#check @TheoremT.Continuum.grushin_gridNorm_base
#check @TheoremT.Continuum.grushin_grid_lower_norm_le
#check @TheoremT.Continuum.grushin_inverse_gap_term_le
#check @TheoremT.Continuum.grushin_scaled_source_le
#check @TheoremT.Continuum.grushin_scaled_factorial_term_le
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.grushinGridNorm
#print axioms TheoremT.Continuum.grushin_grid_time_bounds
#print axioms TheoremT.Continuum.grushin_gridNorm_nonneg
#print axioms TheoremT.Continuum.grushin_gridNorm_base
#print axioms TheoremT.Continuum.grushin_grid_lower_norm_le
#print axioms TheoremT.Continuum.grushin_inverse_gap_term_le
#print axioms TheoremT.Continuum.grushin_scaled_source_le
#print axioms TheoremT.Continuum.grushin_scaled_factorial_term_le
