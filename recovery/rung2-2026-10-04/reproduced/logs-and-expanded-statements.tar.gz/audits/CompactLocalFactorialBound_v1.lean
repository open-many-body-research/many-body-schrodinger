import CompactLocalFactorialBound_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.compact_factorial_bound_of_neighborhood_family
#check @TheoremT.Continuum.compact_local_factorial_bound_uniform_nhds
#check @TheoremT.Continuum.compact_local_factorial_bound_uniform
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.compact_factorial_bound_of_neighborhood_family
#print axioms TheoremT.Continuum.compact_local_factorial_bound_uniform_nhds
#print axioms TheoremT.Continuum.compact_local_factorial_bound_uniform
