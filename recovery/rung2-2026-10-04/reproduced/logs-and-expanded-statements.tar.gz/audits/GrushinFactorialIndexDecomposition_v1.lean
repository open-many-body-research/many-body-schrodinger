import GrushinFactorialIndexDecomposition_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.WeakGrushin.finite_submultiindex_degree
#check @TheoremT.Continuum.WeakGrushin.factorial_submultiindex_degree
#check @TheoremT.Continuum.WeakGrushin.factorial_index_split_with_loss
#check @TheoremT.Continuum.WeakGrushin.factorial_second_cutoff_outer_split
#check @TheoremT.Continuum.WeakGrushin.factorial_first_cutoff_y_outer_split
#check @TheoremT.Continuum.WeakGrushin.factorial_first_cutoff_t_outer_split
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.WeakGrushin.finite_submultiindex_degree
#print axioms TheoremT.Continuum.WeakGrushin.factorial_submultiindex_degree
#print axioms TheoremT.Continuum.WeakGrushin.factorial_index_split_with_loss
#print axioms TheoremT.Continuum.WeakGrushin.factorial_second_cutoff_outer_split
#print axioms TheoremT.Continuum.WeakGrushin.factorial_first_cutoff_y_outer_split
#print axioms TheoremT.Continuum.WeakGrushin.factorial_first_cutoff_t_outer_split
