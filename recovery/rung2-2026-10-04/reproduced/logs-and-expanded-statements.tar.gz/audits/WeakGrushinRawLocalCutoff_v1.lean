import WeakGrushinRawLocalCutoff_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.WeakGrushin.principal_ae_eq_of_raw_local_output
#check @TheoremT.Continuum.WeakGrushin.rawGrushinCutoffError_zero_off
#check @TheoremT.Continuum.WeakGrushin.raw_local_weakH2_grushin_cutoff
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.WeakGrushin.principal_ae_eq_of_raw_local_output
#print axioms TheoremT.Continuum.WeakGrushin.rawGrushinCutoffError_zero_off
#print axioms TheoremT.Continuum.WeakGrushin.raw_local_weakH2_grushin_cutoff
