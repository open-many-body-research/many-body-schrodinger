import PairCoordinatesLaplacian_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.pair_coordinates_bilinear_trace
#check @TheoremT.Continuum.pair_coordinates_weighted_laplacian
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.pair_coordinates_bilinear_trace
#print axioms TheoremT.Continuum.pair_coordinates_weighted_laplacian
