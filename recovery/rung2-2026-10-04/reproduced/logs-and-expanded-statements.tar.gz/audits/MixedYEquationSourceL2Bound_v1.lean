import MixedYEquationSourceL2Bound_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.WeakGrushin.complex_finite_family_L2_bound
#check @TheoremT.Continuum.WeakGrushin.mixedYEquationSource_region_L2_bound
#check @TheoremT.Continuum.WeakGrushin.mixedYEquationSource_budget_le_uniform
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.WeakGrushin.complex_finite_family_L2_bound
#print axioms TheoremT.Continuum.WeakGrushin.mixedYEquationSource_region_L2_bound
#print axioms TheoremT.Continuum.WeakGrushin.mixedYEquationSource_budget_le_uniform
