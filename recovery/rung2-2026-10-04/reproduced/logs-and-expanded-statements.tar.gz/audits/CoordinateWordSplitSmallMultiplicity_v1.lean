import CoordinateWordSplitSmallMultiplicity_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.WeakGrushin.wordSplitLeftCount
#check @TheoremT.Continuum.WeakGrushin.wordSplitLeftCount_empty
#check @TheoremT.Continuum.WeakGrushin.wordSplitLeftCount_cons_cons
#check @TheoremT.Continuum.WeakGrushin.wordSplitLeftCount_singleton
#check @TheoremT.Continuum.WeakGrushin.wordSplitLeftCount_pair
#check @TheoremT.Continuum.WeakGrushin.list_sum_indicator_const
#check @TheoremT.Continuum.WeakGrushin.wordSplit_sum_indicator_const
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.WeakGrushin.wordSplitLeftCount
#print axioms TheoremT.Continuum.WeakGrushin.wordSplitLeftCount_empty
#print axioms TheoremT.Continuum.WeakGrushin.wordSplitLeftCount_cons_cons
#print axioms TheoremT.Continuum.WeakGrushin.wordSplitLeftCount_singleton
#print axioms TheoremT.Continuum.WeakGrushin.wordSplitLeftCount_pair
#print axioms TheoremT.Continuum.WeakGrushin.list_sum_indicator_const
#print axioms TheoremT.Continuum.WeakGrushin.wordSplit_sum_indicator_const
