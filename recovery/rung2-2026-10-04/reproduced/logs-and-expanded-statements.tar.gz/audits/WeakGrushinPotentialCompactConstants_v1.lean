import WeakGrushinPotentialCompactConstants_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.WeakGrushin.l2_setIntegral_norm_sq_le
#check @TheoremT.Continuum.WeakGrushin.compact_spectator_coefficient_bounds_exist
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.WeakGrushin.l2_setIntegral_norm_sq_le
#print axioms TheoremT.Continuum.WeakGrushin.compact_spectator_coefficient_bounds_exist
