import PhysicalKSUniformSourceVolume_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.physicalKSUniformSourceVolume
#check @TheoremT.Continuum.physicalKSUniformSourceVolume_nonneg
#check @TheoremT.Continuum.physicalKS_box_subset_fixed_ball
#check @TheoremT.Continuum.physicalKS_box_volume_bound
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.physicalKSUniformSourceVolume
#print axioms TheoremT.Continuum.physicalKSUniformSourceVolume_nonneg
#print axioms TheoremT.Continuum.physicalKS_box_subset_fixed_ball
#print axioms TheoremT.Continuum.physicalKS_box_volume_bound
