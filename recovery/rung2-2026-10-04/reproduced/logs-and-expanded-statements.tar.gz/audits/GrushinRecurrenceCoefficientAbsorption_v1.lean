import GrushinRecurrenceCoefficientAbsorption_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.grushin_first_two_le_geometric_sum
#check @TheoremT.Continuum.grushin_recurrence_power_coefficient_le
#check @TheoremT.Continuum.grushin_recurrence_coefficient_absorption
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.grushin_first_two_le_geometric_sum
#print axioms TheoremT.Continuum.grushin_recurrence_power_coefficient_le
#print axioms TheoremT.Continuum.grushin_recurrence_coefficient_absorption
