import SpectatorFiniteFamilyExtension_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.WeakGrushin.spectatorFamilyExtend
#check @TheoremT.Continuum.WeakGrushin.spectatorFamilyExtend_old
#check @TheoremT.Continuum.WeakGrushin.spectatorFamilyExtend_top
#check @TheoremT.Continuum.WeakGrushin.spectatorFamilyExtend_genuine
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.WeakGrushin.spectatorFamilyExtend
#print axioms TheoremT.Continuum.WeakGrushin.spectatorFamilyExtend_old
#print axioms TheoremT.Continuum.WeakGrushin.spectatorFamilyExtend_top
#print axioms TheoremT.Continuum.WeakGrushin.spectatorFamilyExtend_genuine
