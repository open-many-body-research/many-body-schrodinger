import GrushinFactorialUnweightedComponent_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.WeakGrushin.factorial_unweighted_outer_mem
#check @TheoremT.Continuum.WeakGrushin.factorial_shifted_unweighted_outer_L2
#check @TheoremT.Continuum.WeakGrushin.factorial_unweighted_component_L2
#check @TheoremT.Continuum.WeakGrushin.factorial_unweighted_lower_order_L2
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.WeakGrushin.factorial_unweighted_outer_mem
#print axioms TheoremT.Continuum.WeakGrushin.factorial_shifted_unweighted_outer_L2
#print axioms TheoremT.Continuum.WeakGrushin.factorial_unweighted_component_L2
#print axioms TheoremT.Continuum.WeakGrushin.factorial_unweighted_lower_order_L2
