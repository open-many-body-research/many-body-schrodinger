import CompactSlabPoincare_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.compact_slab_weight_integral_bound
#check @TheoremT.Continuum.compact_slab_poincare_integral
#check @TheoremT.Continuum.compact_product_y_slab_poincare
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.compact_slab_weight_integral_bound
#print axioms TheoremT.Continuum.compact_slab_poincare_integral
#print axioms TheoremT.Continuum.compact_product_y_slab_poincare
