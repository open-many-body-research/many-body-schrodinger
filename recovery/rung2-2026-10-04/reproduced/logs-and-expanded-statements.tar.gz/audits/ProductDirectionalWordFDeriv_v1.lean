import ProductDirectionalWordFDeriv_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.WeakGrushin.directionalWordDirections
#check @TheoremT.Continuum.WeakGrushin.directionalWordDirections_norm_le
#check @TheoremT.Continuum.WeakGrushin.directionalWordDeriv_eq_iteratedFDeriv
#check @TheoremT.Continuum.WeakGrushin.directionalWordDeriv_abs_le_iteratedFDeriv
#check @TheoremT.Continuum.WeakGrushin.directionalWordDeriv_finite_bound
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.WeakGrushin.directionalWordDirections
#print axioms TheoremT.Continuum.WeakGrushin.directionalWordDirections_norm_le
#print axioms TheoremT.Continuum.WeakGrushin.directionalWordDeriv_eq_iteratedFDeriv
#print axioms TheoremT.Continuum.WeakGrushin.directionalWordDeriv_abs_le_iteratedFDeriv
#print axioms TheoremT.Continuum.WeakGrushin.directionalWordDeriv_finite_bound
