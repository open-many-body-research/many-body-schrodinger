import MixedYIterationBudgetSequence_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.WeakGrushin.mixedYIterationBudgetSeq
#check @TheoremT.Continuum.WeakGrushin.mixedYIterationBudgetSeq_nonneg
#check @TheoremT.Continuum.WeakGrushin.mixedYIterationBudgetSeq_le_succ
#check @TheoremT.Continuum.WeakGrushin.mixedYIterationBudgetSeq_monotone
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.WeakGrushin.mixedYIterationBudgetSeq
#print axioms TheoremT.Continuum.WeakGrushin.mixedYIterationBudgetSeq_nonneg
#print axioms TheoremT.Continuum.WeakGrushin.mixedYIterationBudgetSeq_le_succ
#print axioms TheoremT.Continuum.WeakGrushin.mixedYIterationBudgetSeq_monotone
