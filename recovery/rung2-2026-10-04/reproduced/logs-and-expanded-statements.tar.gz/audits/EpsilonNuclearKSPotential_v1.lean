import EpsilonNuclearKSPotential_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.epsilonNuclearKSPotential
#check @TheoremT.Continuum.nuclearKSPotential_energy_affine
#check @TheoremT.Continuum.epsilonNuclearKSPotential_energy_affine
#check @TheoremT.Continuum.epsilonNuclearKSPotential_eq_coulomb_scaled
#check @TheoremT.Continuum.epsilonNuclearKSPotential_on_zero
#check @TheoremT.Continuum.epsilonNuclearKSPotential_contDiffAt
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.epsilonNuclearKSPotential
#print axioms TheoremT.Continuum.nuclearKSPotential_energy_affine
#print axioms TheoremT.Continuum.epsilonNuclearKSPotential_energy_affine
#print axioms TheoremT.Continuum.epsilonNuclearKSPotential_eq_coulomb_scaled
#print axioms TheoremT.Continuum.epsilonNuclearKSPotential_on_zero
#print axioms TheoremT.Continuum.epsilonNuclearKSPotential_contDiffAt
