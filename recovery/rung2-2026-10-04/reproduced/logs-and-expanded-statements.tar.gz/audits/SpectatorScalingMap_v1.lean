import SpectatorScalingMap_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.spectatorScalingMap
#check @TheoremT.Continuum.spectatorScalingMap_analyticAt
#check @TheoremT.Continuum.spectatorScalingMap_inverse_cancel
#check @TheoremT.Continuum.spectatorScalingMap_inverse_norm_le_one
#check @TheoremT.Continuum.homogeneousSpectatorSum_rescaling
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.spectatorScalingMap
#print axioms TheoremT.Continuum.spectatorScalingMap_analyticAt
#print axioms TheoremT.Continuum.spectatorScalingMap_inverse_cancel
#print axioms TheoremT.Continuum.spectatorScalingMap_inverse_norm_le_one
#print axioms TheoremT.Continuum.homogeneousSpectatorSum_rescaling
