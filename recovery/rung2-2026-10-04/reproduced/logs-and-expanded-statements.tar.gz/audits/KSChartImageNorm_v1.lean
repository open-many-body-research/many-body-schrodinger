import KSChartImageNorm_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.nuclearKSLift_norm_sq
#check @TheoremT.Continuum.pairKSLift_norm_sq
#check @TheoremT.Continuum.nuclearKSLift_norm_lt_two
#check @TheoremT.Continuum.pairKSLift_norm_lt_two
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.nuclearKSLift_norm_sq
#print axioms TheoremT.Continuum.pairKSLift_norm_sq
#print axioms TheoremT.Continuum.nuclearKSLift_norm_lt_two
#print axioms TheoremT.Continuum.pairKSLift_norm_lt_two
