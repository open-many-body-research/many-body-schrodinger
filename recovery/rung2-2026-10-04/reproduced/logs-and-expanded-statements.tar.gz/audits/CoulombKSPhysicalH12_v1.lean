import CoulombKSPhysicalH12_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.scalar_coulomb_nuclear_zero_physical_coordinate_h12
#check @TheoremT.Continuum.scalar_coulomb_pair_physical_coordinate_h12
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.scalar_coulomb_nuclear_zero_physical_coordinate_h12
#print axioms TheoremT.Continuum.scalar_coulomb_pair_physical_coordinate_h12
