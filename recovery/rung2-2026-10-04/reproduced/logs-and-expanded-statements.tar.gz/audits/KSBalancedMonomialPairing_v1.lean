import KSBalancedMonomialPairing_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.ksBalancedMonomialPairing
#check @TheoremT.Continuum.ksBalancedMonomialPairing_entries
#check @TheoremT.Continuum.ksBalancedMonomialPairing_margins
#check @TheoremT.Continuum.ksBalancedMonomialPairing_row_sum
#check @TheoremT.Continuum.ksBalancedMonomialPairing_column_sum
#check @TheoremT.Continuum.ksBalancedMonomialPairing_last_eq_remainder
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.ksBalancedMonomialPairing
#print axioms TheoremT.Continuum.ksBalancedMonomialPairing_entries
#print axioms TheoremT.Continuum.ksBalancedMonomialPairing_margins
#print axioms TheoremT.Continuum.ksBalancedMonomialPairing_row_sum
#print axioms TheoremT.Continuum.ksBalancedMonomialPairing_column_sum
#print axioms TheoremT.Continuum.ksBalancedMonomialPairing_last_eq_remainder
