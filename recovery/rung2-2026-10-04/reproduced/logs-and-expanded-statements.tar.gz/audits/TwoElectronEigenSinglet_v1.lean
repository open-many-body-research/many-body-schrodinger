import TwoElectronEigenSinglet_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.spinSingletLift_hydrogen_inner
#check @TheoremT.Continuum.twoElectron_low_eigen_zero_of_overlap_zero
#check @TheoremT.Continuum.twoElectron_low_eigen_singlet
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.spinSingletLift_hydrogen_inner
#print axioms TheoremT.Continuum.twoElectron_low_eigen_zero_of_overlap_zero
#print axioms TheoremT.Continuum.twoElectron_low_eigen_singlet
