import SpectatorTotalDegreeIndices_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.spectatorTotalDegreeIndices
#check @TheoremT.Continuum.mem_spectatorTotalDegreeIndices_iff
#check @TheoremT.Continuum.card_spectatorTotalDegreeIndices
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.spectatorTotalDegreeIndices
#print axioms TheoremT.Continuum.mem_spectatorTotalDegreeIndices_iff
#print axioms TheoremT.Continuum.card_spectatorTotalDegreeIndices
