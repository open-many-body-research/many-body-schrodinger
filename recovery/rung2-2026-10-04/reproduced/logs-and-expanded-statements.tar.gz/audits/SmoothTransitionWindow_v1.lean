import SmoothTransitionWindow_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.smoothTransition_derivative_bounds
#check @TheoremT.Continuum.transitionWindow
#check @TheoremT.Continuum.transitionWindow_contDiff
#check @TheoremT.Continuum.transitionWindow_nonneg
#check @TheoremT.Continuum.transitionWindow_le_one
#check @TheoremT.Continuum.transitionWindow_plateau
#check @TheoremT.Continuum.transitionWindow_tsupport
#check @TheoremT.Continuum.transitionWindow_compact
#check @TheoremT.Continuum.transitionWindow_first
#check @TheoremT.Continuum.transitionWindow_second
#check @TheoremT.Continuum.transitionWindow_first_bound
#check @TheoremT.Continuum.transitionWindow_second_bound
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.smoothTransition_derivative_bounds
#print axioms TheoremT.Continuum.transitionWindow
#print axioms TheoremT.Continuum.transitionWindow_contDiff
#print axioms TheoremT.Continuum.transitionWindow_nonneg
#print axioms TheoremT.Continuum.transitionWindow_le_one
#print axioms TheoremT.Continuum.transitionWindow_plateau
#print axioms TheoremT.Continuum.transitionWindow_tsupport
#print axioms TheoremT.Continuum.transitionWindow_compact
#print axioms TheoremT.Continuum.transitionWindow_first
#print axioms TheoremT.Continuum.transitionWindow_second
#print axioms TheoremT.Continuum.transitionWindow_first_bound
#print axioms TheoremT.Continuum.transitionWindow_second_bound
