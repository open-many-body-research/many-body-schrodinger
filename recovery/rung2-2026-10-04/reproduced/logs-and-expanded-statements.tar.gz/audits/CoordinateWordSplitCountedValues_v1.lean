import CoordinateWordSplitCountedValues_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.WeakGrushin.factorialWordSplits_right_counts
#check @TheoremT.Continuum.WeakGrushin.wordSplit_sum_indicator_counted
#check @TheoremT.Continuum.WeakGrushin.wordProperSplit_sum_indicator_counted
#check @TheoremT.Continuum.WeakGrushin.wordProperSplit_counted_singleton
#check @TheoremT.Continuum.WeakGrushin.wordProperSplit_counted_pair
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.WeakGrushin.factorialWordSplits_right_counts
#print axioms TheoremT.Continuum.WeakGrushin.wordSplit_sum_indicator_counted
#print axioms TheoremT.Continuum.WeakGrushin.wordProperSplit_sum_indicator_counted
#print axioms TheoremT.Continuum.WeakGrushin.wordProperSplit_counted_singleton
#print axioms TheoremT.Continuum.WeakGrushin.wordProperSplit_counted_pair
