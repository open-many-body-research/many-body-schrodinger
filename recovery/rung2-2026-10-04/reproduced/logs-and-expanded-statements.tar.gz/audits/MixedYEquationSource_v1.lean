import MixedYEquationSource_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.WeakGrushin.mixedYEquationSource
#check @TheoremT.Continuum.WeakGrushin.mixedYEquationSource_locallyL2
#check @TheoremT.Continuum.WeakGrushin.mixedYEquationSource_localY
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.WeakGrushin.mixedYEquationSource
#print axioms TheoremT.Continuum.WeakGrushin.mixedYEquationSource_locallyL2
#print axioms TheoremT.Continuum.WeakGrushin.mixedYEquationSource_localY
