import SmoothMixedSourceWords_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.WeakGrushin.productLocalWeakDirectional_constant
#check @TheoremT.Continuum.WeakGrushin.smooth_mixed_source_words
#check @TheoremT.Continuum.WeakGrushin.smooth_mixed_source_region_budget
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.WeakGrushin.productLocalWeakDirectional_constant
#print axioms TheoremT.Continuum.WeakGrushin.smooth_mixed_source_words
#print axioms TheoremT.Continuum.WeakGrushin.smooth_mixed_source_region_budget
