import GrushinCoordinateBoxGeometry_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.WeakGrushin.boxCoordinate
#check @TheoremT.Continuum.WeakGrushin.boxDirection
#check @TheoremT.Continuum.WeakGrushin.boxCoordinate_direction
#check @TheoremT.Continuum.WeakGrushin.coordinateClosedBox
#check @TheoremT.Continuum.WeakGrushin.coordinateClosedBox_isClosed
#check @TheoremT.Continuum.WeakGrushin.coordinateClosedBox_y_norm
#check @TheoremT.Continuum.WeakGrushin.coordinateClosedBox_t_norm
#check @TheoremT.Continuum.WeakGrushin.coordinateClosedBox_subset_closedBall
#check @TheoremT.Continuum.WeakGrushin.coordinateClosedBox_isCompact
#check @TheoremT.Continuum.WeakGrushin.coordinateClosedBox_y_radius
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.WeakGrushin.boxCoordinate
#print axioms TheoremT.Continuum.WeakGrushin.boxDirection
#print axioms TheoremT.Continuum.WeakGrushin.boxCoordinate_direction
#print axioms TheoremT.Continuum.WeakGrushin.coordinateClosedBox
#print axioms TheoremT.Continuum.WeakGrushin.coordinateClosedBox_isClosed
#print axioms TheoremT.Continuum.WeakGrushin.coordinateClosedBox_y_norm
#print axioms TheoremT.Continuum.WeakGrushin.coordinateClosedBox_t_norm
#print axioms TheoremT.Continuum.WeakGrushin.coordinateClosedBox_subset_closedBall
#print axioms TheoremT.Continuum.WeakGrushin.coordinateClosedBox_isCompact
#print axioms TheoremT.Continuum.WeakGrushin.coordinateClosedBox_y_radius
