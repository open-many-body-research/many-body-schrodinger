import PhysicalKSTaylorCoordinatePolynomials_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.physicalKSTaylorPolynomial
#check @TheoremT.Continuum.physicalKSTaylorPolynomial_homogeneous
#check @TheoremT.Continuum.physicalKSTaylorPolynomial_coefficientL1
#check @TheoremT.Continuum.physicalKSTaylorPolynomial_common_radius
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.physicalKSTaylorPolynomial
#print axioms TheoremT.Continuum.physicalKSTaylorPolynomial_homogeneous
#print axioms TheoremT.Continuum.physicalKSTaylorPolynomial_coefficientL1
#print axioms TheoremT.Continuum.physicalKSTaylorPolynomial_common_radius
