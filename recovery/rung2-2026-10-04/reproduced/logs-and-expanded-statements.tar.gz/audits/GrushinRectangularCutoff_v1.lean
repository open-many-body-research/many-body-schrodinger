import GrushinRectangularCutoff_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.WeakGrushin.grushinRectCutoff
#check @TheoremT.Continuum.WeakGrushin.grushinRectCutoff_apply
#check @TheoremT.Continuum.WeakGrushin.grushinRectCutoff_contDiff
#check @TheoremT.Continuum.WeakGrushin.grushinRectCutoff_nonneg
#check @TheoremT.Continuum.WeakGrushin.grushinRectCutoff_le_one
#check @TheoremT.Continuum.WeakGrushin.grushinRectCutoff_plateau
#check @TheoremT.Continuum.WeakGrushin.grushinRectCutoff_tsupport
#check @TheoremT.Continuum.WeakGrushin.grushinRectCutoff_compact
#check @TheoremT.Continuum.WeakGrushin.grushinRectCutoff_first_bound
#check @TheoremT.Continuum.WeakGrushin.grushinRectCutoff_second_bound
#check @TheoremT.Continuum.WeakGrushin.grushinRectCutoff_coefficients
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.WeakGrushin.grushinRectCutoff
#print axioms TheoremT.Continuum.WeakGrushin.grushinRectCutoff_apply
#print axioms TheoremT.Continuum.WeakGrushin.grushinRectCutoff_contDiff
#print axioms TheoremT.Continuum.WeakGrushin.grushinRectCutoff_nonneg
#print axioms TheoremT.Continuum.WeakGrushin.grushinRectCutoff_le_one
#print axioms TheoremT.Continuum.WeakGrushin.grushinRectCutoff_plateau
#print axioms TheoremT.Continuum.WeakGrushin.grushinRectCutoff_tsupport
#print axioms TheoremT.Continuum.WeakGrushin.grushinRectCutoff_compact
#print axioms TheoremT.Continuum.WeakGrushin.grushinRectCutoff_first_bound
#print axioms TheoremT.Continuum.WeakGrushin.grushinRectCutoff_second_bound
#print axioms TheoremT.Continuum.WeakGrushin.grushinRectCutoff_coefficients
