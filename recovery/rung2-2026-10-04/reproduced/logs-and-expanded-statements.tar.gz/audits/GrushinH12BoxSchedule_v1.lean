import GrushinH12BoxSchedule_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.WeakGrushin.h12BoxGap
#check @TheoremT.Continuum.WeakGrushin.h12BoxRadius
#check @TheoremT.Continuum.WeakGrushin.h12ScheduledBox
#check @TheoremT.Continuum.WeakGrushin.h12BoxGap_pos
#check @TheoremT.Continuum.WeakGrushin.h12BoxGap_y_margin
#check @TheoremT.Continuum.WeakGrushin.h12BoxGap_t_margin
#check @TheoremT.Continuum.WeakGrushin.h12ScheduledBox_isOpen
#check @TheoremT.Continuum.WeakGrushin.h12_target_subset_level34
#check @TheoremT.Continuum.WeakGrushin.h12BoxRadius_two_gap_y
#check @TheoremT.Continuum.WeakGrushin.h12BoxRadius_two_gap_t
#check @TheoremT.Continuum.WeakGrushin.h12ScheduledBox_y_radius
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.WeakGrushin.h12BoxGap
#print axioms TheoremT.Continuum.WeakGrushin.h12BoxRadius
#print axioms TheoremT.Continuum.WeakGrushin.h12ScheduledBox
#print axioms TheoremT.Continuum.WeakGrushin.h12BoxGap_pos
#print axioms TheoremT.Continuum.WeakGrushin.h12BoxGap_y_margin
#print axioms TheoremT.Continuum.WeakGrushin.h12BoxGap_t_margin
#print axioms TheoremT.Continuum.WeakGrushin.h12ScheduledBox_isOpen
#print axioms TheoremT.Continuum.WeakGrushin.h12_target_subset_level34
#print axioms TheoremT.Continuum.WeakGrushin.h12BoxRadius_two_gap_y
#print axioms TheoremT.Continuum.WeakGrushin.h12BoxRadius_two_gap_t
#print axioms TheoremT.Continuum.WeakGrushin.h12ScheduledBox_y_radius
