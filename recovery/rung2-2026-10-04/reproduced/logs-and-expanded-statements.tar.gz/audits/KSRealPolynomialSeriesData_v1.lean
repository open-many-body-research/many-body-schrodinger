import KSRealPolynomialSeriesData_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.ksRealPolynomialSeriesA
#check @TheoremT.Continuum.ksRealPolynomialSeriesB
#check @TheoremT.Continuum.ks_real_polynomial_series_data
#check @TheoremT.Continuum.ks_real_polynomial_series_analytic
#check @TheoremT.Continuum.ks_real_polynomial_series_norm_bounds
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.ksRealPolynomialSeriesA
#print axioms TheoremT.Continuum.ksRealPolynomialSeriesB
#print axioms TheoremT.Continuum.ks_real_polynomial_series_data
#print axioms TheoremT.Continuum.ks_real_polynomial_series_analytic
#print axioms TheoremT.Continuum.ks_real_polynomial_series_norm_bounds
