import IntervalPointwiseFTC_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.interval_norm_sub_le_derivative_integral
#check @TheoremT.Continuum.interval_pointwise_norm_mul_length_le
#check @TheoremT.Continuum.interval_pointwise_norm_le_average_derivative
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.interval_norm_sub_le_derivative_integral
#print axioms TheoremT.Continuum.interval_pointwise_norm_mul_length_le
#print axioms TheoremT.Continuum.interval_pointwise_norm_le_average_derivative
