import SevenCoordinateRepresentativeReturn_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.sevenToProduct_symm_measurePreserving
#check @TheoremT.Continuum.sevenToProduct_ae_return
#check @TheoremT.Continuum.seven_coordinate_smooth_representative_return
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.sevenToProduct_symm_measurePreserving
#print axioms TheoremT.Continuum.sevenToProduct_ae_return
#print axioms TheoremT.Continuum.seven_coordinate_smooth_representative_return
