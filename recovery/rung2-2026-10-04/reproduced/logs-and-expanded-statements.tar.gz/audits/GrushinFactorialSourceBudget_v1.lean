import GrushinFactorialSourceBudget_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.WeakGrushin.RegionL2Budget.exists_L2_norm_le
#check @TheoremT.Continuum.WeakGrushin.factorial_growth_mono
#check @TheoremT.Continuum.WeakGrushin.factorial_source_budget_representative
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.WeakGrushin.RegionL2Budget.exists_L2_norm_le
#print axioms TheoremT.Continuum.WeakGrushin.factorial_growth_mono
#print axioms TheoremT.Continuum.WeakGrushin.factorial_source_budget_representative
