import FiniteLpTraceBounds_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.finite_sum_norm_sq_le_card_sum_norm_sq
#check @TheoremT.Continuum.trace_norm_add_sq_le_weighted
#check @TheoremT.Continuum.grouped_sum_norm_sq_le_weighted_card_sums
#check @TheoremT.Continuum.grouped_sum_norm_sq_le_card_sums
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.finite_sum_norm_sq_le_card_sum_norm_sq
#print axioms TheoremT.Continuum.trace_norm_add_sq_le_weighted
#print axioms TheoremT.Continuum.grouped_sum_norm_sq_le_weighted_card_sums
#print axioms TheoremT.Continuum.grouped_sum_norm_sq_le_card_sums
