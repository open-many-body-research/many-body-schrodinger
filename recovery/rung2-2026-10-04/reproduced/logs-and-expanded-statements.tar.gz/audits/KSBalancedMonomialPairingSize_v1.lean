import KSBalancedMonomialPairingSize_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.ksBalancedMonomialPairing_total
#check @TheoremT.Continuum.ksBalancedMonomialPairing_four_total
#check @TheoremT.Continuum.ksBalancedMonomialPairing_entry_le_total
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.ksBalancedMonomialPairing_total
#print axioms TheoremT.Continuum.ksBalancedMonomialPairing_four_total
#print axioms TheoremT.Continuum.ksBalancedMonomialPairing_entry_le_total
