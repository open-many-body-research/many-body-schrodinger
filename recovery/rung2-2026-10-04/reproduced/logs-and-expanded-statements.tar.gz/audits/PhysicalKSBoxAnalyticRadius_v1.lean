import PhysicalKSBoxAnalyticRadius_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.physical_boxCoordinate_abs_le_norm
#check @TheoremT.Continuum.physical_fixed_box_ball_room
#check @TheoremT.Continuum.physicalKSBoxPointwiseData_common_radius
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.physical_boxCoordinate_abs_le_norm
#print axioms TheoremT.Continuum.physical_fixed_box_ball_room
#print axioms TheoremT.Continuum.physicalKSBoxPointwiseData_common_radius
