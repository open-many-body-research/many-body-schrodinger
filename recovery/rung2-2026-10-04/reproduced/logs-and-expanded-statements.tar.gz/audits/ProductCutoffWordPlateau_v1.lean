import ProductCutoffWordPlateau_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.directionalWordDeriv_constant_open
#check @TheoremT.Continuum.directionalWordProduct_plateau
#check @TheoremT.Continuum.directionalWordProduct_plateau_restrict_ae
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.directionalWordDeriv_constant_open
#print axioms TheoremT.Continuum.directionalWordProduct_plateau
#print axioms TheoremT.Continuum.directionalWordProduct_plateau_restrict_ae
