import GrushinWeightedTHessianIdentity_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.partialTDirectional_fst_smul
#check @TheoremT.Continuum.partialTDirectional_second_fst_smul
#check @TheoremT.Continuum.compact_weighted_t_hessian_identity
#check @TheoremT.Continuum.compact_grushin_full_weighted_hessian_bound
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.partialTDirectional_fst_smul
#print axioms TheoremT.Continuum.partialTDirectional_second_fst_smul
#print axioms TheoremT.Continuum.compact_weighted_t_hessian_identity
#print axioms TheoremT.Continuum.compact_grushin_full_weighted_hessian_bound
