import CoulombKSPhysicalPointwise_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.PhysicalKSBoxPointwiseData
#check @TheoremT.Continuum.physicalKSBoxFactorialData_to_pointwise
#check @TheoremT.Continuum.scalar_coulomb_all_physical_box_pointwise
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.PhysicalKSBoxPointwiseData
#print axioms TheoremT.Continuum.physicalKSBoxFactorialData_to_pointwise
#print axioms TheoremT.Continuum.scalar_coulomb_all_physical_box_pointwise
