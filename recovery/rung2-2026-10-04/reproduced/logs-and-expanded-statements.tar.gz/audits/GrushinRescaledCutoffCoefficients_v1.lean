import GrushinRescaledCutoffCoefficients_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.WeakGrushin.cutoff_yDir_norm
#check @TheoremT.Continuum.WeakGrushin.cutoff_tDir_norm
#check @TheoremT.Continuum.WeakGrushin.cutoffRescale_y_radius
#check @TheoremT.Continuum.WeakGrushin.cutoffRescale_grushin_family
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.WeakGrushin.cutoff_yDir_norm
#print axioms TheoremT.Continuum.WeakGrushin.cutoff_tDir_norm
#print axioms TheoremT.Continuum.WeakGrushin.cutoffRescale_y_radius
#print axioms TheoremT.Continuum.WeakGrushin.cutoffRescale_grushin_family
