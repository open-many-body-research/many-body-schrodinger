import ProductMixedAllOrderWeakFamily_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.WeakGrushin.product_mixed_allOrder_weak_family
#check @TheoremT.Continuum.WeakGrushin.local_smooth_weak_grushin_allOrder_family
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.WeakGrushin.product_mixed_allOrder_weak_family
#print axioms TheoremT.Continuum.WeakGrushin.local_smooth_weak_grushin_allOrder_family
