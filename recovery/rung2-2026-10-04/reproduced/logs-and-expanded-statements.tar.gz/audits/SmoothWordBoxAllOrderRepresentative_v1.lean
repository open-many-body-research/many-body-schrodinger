import SmoothWordBoxAllOrderRepresentative_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.compatible_coordinate_words7_eq
#check @TheoremT.Continuum.smooth_words7_allOrder_representative_of_L2_limits
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.compatible_coordinate_words7_eq
#print axioms TheoremT.Continuum.smooth_words7_allOrder_representative_of_L2_limits
