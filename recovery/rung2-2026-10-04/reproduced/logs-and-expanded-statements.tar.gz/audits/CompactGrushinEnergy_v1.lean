import CompactGrushinEnergy_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.compact_grushin_energy
#check @TheoremT.Continuum.grushin_gradient_energy_nonneg
#check @TheoremT.Continuum.grushin_y_gradient_le_energy
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.compact_grushin_energy
#print axioms TheoremT.Continuum.grushin_gradient_energy_nonneg
#print axioms TheoremT.Continuum.grushin_y_gradient_le_energy
