import GrushinQuadraticCountedCommutator_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.WeakGrushin.list_sum_finset_sum
#check @TheoremT.Continuum.WeakGrushin.real_two_mul_choose_two
#check @TheoremT.Continuum.WeakGrushin.grushin_quadratic_counted_commutator
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.WeakGrushin.list_sum_finset_sum
#print axioms TheoremT.Continuum.WeakGrushin.real_two_mul_choose_two
#print axioms TheoremT.Continuum.WeakGrushin.grushin_quadratic_counted_commutator
