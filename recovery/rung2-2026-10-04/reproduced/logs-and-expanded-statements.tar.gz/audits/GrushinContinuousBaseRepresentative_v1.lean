import GrushinContinuousBaseRepresentative_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.WeakGrushin.complex_word_congr_on_open
#check @TheoremT.Continuum.WeakGrushin.grushin_actual_profile_continuous_base
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.WeakGrushin.complex_word_congr_on_open
#print axioms TheoremT.Continuum.WeakGrushin.grushin_actual_profile_continuous_base
