import GrushinFactorialPrincipalIndexedBound_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.WeakGrushin.factorialPrincipalRawError
#check @TheoremT.Continuum.WeakGrushin.factorialOuterNorm_nonneg
#check @TheoremT.Continuum.WeakGrushin.lp_double_sum_ae
#check @TheoremT.Continuum.WeakGrushin.factorial_principal_indexed_error_L2
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.WeakGrushin.factorialPrincipalRawError
#print axioms TheoremT.Continuum.WeakGrushin.factorialOuterNorm_nonneg
#print axioms TheoremT.Continuum.WeakGrushin.lp_double_sum_ae
#print axioms TheoremT.Continuum.WeakGrushin.factorial_principal_indexed_error_L2
