import GrushinRectangularBoxGeometry_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.WeakGrushin.boxHalfWidth
#check @TheoremT.Continuum.WeakGrushin.rectangularClosedBox
#check @TheoremT.Continuum.WeakGrushin.rectangularOpenBox
#check @TheoremT.Continuum.WeakGrushin.rectangularClosedBox_isClosed
#check @TheoremT.Continuum.WeakGrushin.rectangularOpenBox_isOpen
#check @TheoremT.Continuum.WeakGrushin.rectangularClosedBox_subset_coordinateClosedBox
#check @TheoremT.Continuum.WeakGrushin.rectangularClosedBox_isCompact
#check @TheoremT.Continuum.WeakGrushin.rectangularClosedBox_y_norm
#check @TheoremT.Continuum.WeakGrushin.rectangularClosedBox_y_radius
#check @TheoremT.Continuum.WeakGrushin.rectangularClosedBox_subset_openBox
#check @TheoremT.Continuum.WeakGrushin.rectangularOpenBox_subset_closedBox
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.WeakGrushin.boxHalfWidth
#print axioms TheoremT.Continuum.WeakGrushin.rectangularClosedBox
#print axioms TheoremT.Continuum.WeakGrushin.rectangularOpenBox
#print axioms TheoremT.Continuum.WeakGrushin.rectangularClosedBox_isClosed
#print axioms TheoremT.Continuum.WeakGrushin.rectangularOpenBox_isOpen
#print axioms TheoremT.Continuum.WeakGrushin.rectangularClosedBox_subset_coordinateClosedBox
#print axioms TheoremT.Continuum.WeakGrushin.rectangularClosedBox_isCompact
#print axioms TheoremT.Continuum.WeakGrushin.rectangularClosedBox_y_norm
#print axioms TheoremT.Continuum.WeakGrushin.rectangularClosedBox_y_radius
#print axioms TheoremT.Continuum.WeakGrushin.rectangularClosedBox_subset_openBox
#print axioms TheoremT.Continuum.WeakGrushin.rectangularOpenBox_subset_closedBox
