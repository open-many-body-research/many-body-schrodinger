import GrushinWordSplitCoordinateCount_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.WeakGrushin.spectatorWordSplits_countP
#check @TheoremT.Continuum.WeakGrushin.factorial_word_sum_coordinate_counts
#check @TheoremT.Continuum.WeakGrushin.factorialWordYCount
#check @TheoremT.Continuum.WeakGrushin.factorialWordTCount
#check @TheoremT.Continuum.WeakGrushin.factorialWordCounts_length
#check @TheoremT.Continuum.WeakGrushin.factorialWordSplits_counts
#check @TheoremT.Continuum.WeakGrushin.factorialWordSplits_cost_loss
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.WeakGrushin.spectatorWordSplits_countP
#print axioms TheoremT.Continuum.WeakGrushin.factorial_word_sum_coordinate_counts
#print axioms TheoremT.Continuum.WeakGrushin.factorialWordYCount
#print axioms TheoremT.Continuum.WeakGrushin.factorialWordTCount
#print axioms TheoremT.Continuum.WeakGrushin.factorialWordCounts_length
#print axioms TheoremT.Continuum.WeakGrushin.factorialWordSplits_counts
#print axioms TheoremT.Continuum.WeakGrushin.factorialWordSplits_cost_loss
