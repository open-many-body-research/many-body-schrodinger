import GrushinWordSplitBinomialNorm_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.WeakGrushin.factorial_norm_list_map_sum_le
#check @TheoremT.Continuum.WeakGrushin.factorial_lp_list_map_sum_ae
#check @TheoremT.Continuum.WeakGrushin.factorial_word_proper_binomial_norm_bound
#check @TheoremT.Continuum.WeakGrushin.factorial_word_proper_binomial_L2_bound
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.WeakGrushin.factorial_norm_list_map_sum_le
#print axioms TheoremT.Continuum.WeakGrushin.factorial_lp_list_map_sum_ae
#print axioms TheoremT.Continuum.WeakGrushin.factorial_word_proper_binomial_norm_bound
#print axioms TheoremT.Continuum.WeakGrushin.factorial_word_proper_binomial_L2_bound
