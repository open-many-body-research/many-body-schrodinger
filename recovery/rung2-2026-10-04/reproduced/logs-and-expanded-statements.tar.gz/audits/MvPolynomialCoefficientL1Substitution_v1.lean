import MvPolynomialCoefficientL1Substitution_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.polynomialCoeffL1_substitution_weighted
#check @TheoremT.Continuum.polynomialCoeffL1_substitution_nonexpansive
#check @TheoremT.Continuum.polynomialCoeffL1_coefficient_bound
#check @TheoremT.Continuum.polynomialCoeffL1_eq_zero_iff
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.polynomialCoeffL1_substitution_weighted
#print axioms TheoremT.Continuum.polynomialCoeffL1_substitution_nonexpansive
#print axioms TheoremT.Continuum.polynomialCoeffL1_coefficient_bound
#print axioms TheoremT.Continuum.polynomialCoeffL1_eq_zero_iff
