import SmoothCutoffRescaleBalls_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.cutoffRescaleMap_norm
#check @TheoremT.Continuum.cutoffRescale_closedBall_image
#check @TheoremT.Continuum.cutoffRescale_ball_image
#check @TheoremT.Continuum.cutoffRescale_plateau_closedBall
#check @TheoremT.Continuum.cutoffRescale_plateau_ball
#check @TheoremT.Continuum.cutoffRescale_value_bound
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.cutoffRescaleMap_norm
#print axioms TheoremT.Continuum.cutoffRescale_closedBall_image
#print axioms TheoremT.Continuum.cutoffRescale_ball_image
#print axioms TheoremT.Continuum.cutoffRescale_plateau_closedBall
#print axioms TheoremT.Continuum.cutoffRescale_plateau_ball
#print axioms TheoremT.Continuum.cutoffRescale_value_bound
