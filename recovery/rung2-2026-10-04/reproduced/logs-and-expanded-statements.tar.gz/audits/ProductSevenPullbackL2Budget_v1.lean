import ProductSevenPullbackL2Budget_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.sevenToProduct_restrict_measurePreserving
#check @TheoremT.Continuum.sevenToProduct_integral_restrict_image
#check @TheoremT.Continuum.sevenToProduct_pullback_memLp
#check @TheoremT.Continuum.sevenToProduct_integral_sq_le
#check @TheoremT.Continuum.sevenToProduct_sqrt_integral_le_eLpNorm
#check @TheoremT.Continuum.sevenToProduct_regionL2Budget
#check @TheoremT.Continuum.sevenToProduct_regionL2Budget_sq
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.sevenToProduct_restrict_measurePreserving
#print axioms TheoremT.Continuum.sevenToProduct_integral_restrict_image
#print axioms TheoremT.Continuum.sevenToProduct_pullback_memLp
#print axioms TheoremT.Continuum.sevenToProduct_integral_sq_le
#print axioms TheoremT.Continuum.sevenToProduct_sqrt_integral_le_eLpNorm
#print axioms TheoremT.Continuum.sevenToProduct_regionL2Budget
#print axioms TheoremT.Continuum.sevenToProduct_regionL2Budget_sq
