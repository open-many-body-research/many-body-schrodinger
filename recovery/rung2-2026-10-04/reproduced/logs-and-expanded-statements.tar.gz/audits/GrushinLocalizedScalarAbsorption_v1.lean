import GrushinLocalizedScalarAbsorption_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.grushinLocalizedCoefficient
#check @TheoremT.Continuum.grushin_localized_scalar_absorption
#check @TheoremT.Continuum.grushin_fixed_gap_recurrence_of_localized_bounds
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.grushinLocalizedCoefficient
#print axioms TheoremT.Continuum.grushin_localized_scalar_absorption
#print axioms TheoremT.Continuum.grushin_fixed_gap_recurrence_of_localized_bounds
