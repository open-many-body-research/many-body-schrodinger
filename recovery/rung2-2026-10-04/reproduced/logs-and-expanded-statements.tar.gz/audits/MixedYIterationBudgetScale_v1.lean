import MixedYIterationBudgetScale_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.WeakGrushin.mixedYSourceBudget_input_mono
#check @TheoremT.Continuum.WeakGrushin.mixedYIterationNext_input_mono
#check @TheoremT.Continuum.WeakGrushin.mixedYIterationNext_scale
#check @TheoremT.Continuum.WeakGrushin.mixedYIterationBudgetSeq_scale
#check @TheoremT.Continuum.WeakGrushin.mixedYIterationBudgetSeq_input_mono
#check @TheoremT.Continuum.WeakGrushin.mixedYIterationBudgetSeq_common_bound
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.WeakGrushin.mixedYSourceBudget_input_mono
#print axioms TheoremT.Continuum.WeakGrushin.mixedYIterationNext_input_mono
#print axioms TheoremT.Continuum.WeakGrushin.mixedYIterationNext_scale
#print axioms TheoremT.Continuum.WeakGrushin.mixedYIterationBudgetSeq_scale
#print axioms TheoremT.Continuum.WeakGrushin.mixedYIterationBudgetSeq_input_mono
#print axioms TheoremT.Continuum.WeakGrushin.mixedYIterationBudgetSeq_common_bound
