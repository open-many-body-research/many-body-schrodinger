import MvPolynomialCoefficientL1DegreeBound_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.polynomialCoeffL1_substitution_totalDegree
#check @TheoremT.Continuum.polynomialCoeffL1_substitution_degree_bound
#check @TheoremT.Continuum.polynomial_eval_norm_weighted
#check @TheoremT.Continuum.polynomial_eval_norm_le_coeffL1
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.polynomialCoeffL1_substitution_totalDegree
#print axioms TheoremT.Continuum.polynomialCoeffL1_substitution_degree_bound
#print axioms TheoremT.Continuum.polynomial_eval_norm_weighted
#print axioms TheoremT.Continuum.polynomial_eval_norm_le_coeffL1
