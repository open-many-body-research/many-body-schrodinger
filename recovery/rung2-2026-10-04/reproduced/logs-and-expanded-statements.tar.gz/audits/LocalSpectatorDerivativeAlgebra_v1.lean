import LocalSpectatorDerivativeAlgebra_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.WeakGrushin.LocalSpectatorD
#check @TheoremT.Continuum.WeakGrushin.LocalSpectatorD.zero
#check @TheoremT.Continuum.WeakGrushin.LocalSpectatorD.add
#check @TheoremT.Continuum.WeakGrushin.LocalSpectatorD.neg
#check @TheoremT.Continuum.WeakGrushin.productLocallyL2On_list_sum
#check @TheoremT.Continuum.WeakGrushin.LocalSpectatorD.list_sum
#check @TheoremT.Continuum.WeakGrushin.LocalSpectatorD.mono
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.WeakGrushin.LocalSpectatorD
#print axioms TheoremT.Continuum.WeakGrushin.LocalSpectatorD.zero
#print axioms TheoremT.Continuum.WeakGrushin.LocalSpectatorD.add
#print axioms TheoremT.Continuum.WeakGrushin.LocalSpectatorD.neg
#print axioms TheoremT.Continuum.WeakGrushin.productLocallyL2On_list_sum
#print axioms TheoremT.Continuum.WeakGrushin.LocalSpectatorD.list_sum
#print axioms TheoremT.Continuum.WeakGrushin.LocalSpectatorD.mono
