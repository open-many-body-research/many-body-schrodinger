import KSCommonAnnulusFactorialJets_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.KSScaledFactorialJetControl
#check @TheoremT.Continuum.ksScaledFactorialJetControl_mono
#check @TheoremT.Continuum.ksScaledFactorialJetControl_subset
#check @TheoremT.Continuum.ksCommonAnnulus_uniform_factorial_jets
#check @TheoremT.Continuum.ksCommonAnnulus_uniform_factorial_physical_boxes
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.KSScaledFactorialJetControl
#print axioms TheoremT.Continuum.ksScaledFactorialJetControl_mono
#print axioms TheoremT.Continuum.ksScaledFactorialJetControl_subset
#print axioms TheoremT.Continuum.ksCommonAnnulus_uniform_factorial_jets
#print axioms TheoremT.Continuum.ksCommonAnnulus_uniform_factorial_physical_boxes
