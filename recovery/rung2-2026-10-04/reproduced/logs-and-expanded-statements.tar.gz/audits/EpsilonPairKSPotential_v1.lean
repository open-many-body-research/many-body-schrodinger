import EpsilonPairKSPotential_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.epsilonPairKSPotential
#check @TheoremT.Continuum.pairKSPotential_energy_affine
#check @TheoremT.Continuum.epsilonPairKSPotential_energy_affine
#check @TheoremT.Continuum.epsilonPairKSPotential_eq_coulomb_scaled
#check @TheoremT.Continuum.epsilonPairKSPotential_on_zero
#check @TheoremT.Continuum.epsilonPairKSPotential_contDiffAt
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.epsilonPairKSPotential
#print axioms TheoremT.Continuum.pairKSPotential_energy_affine
#print axioms TheoremT.Continuum.epsilonPairKSPotential_energy_affine
#print axioms TheoremT.Continuum.epsilonPairKSPotential_eq_coulomb_scaled
#print axioms TheoremT.Continuum.epsilonPairKSPotential_on_zero
#print axioms TheoremT.Continuum.epsilonPairKSPotential_contDiffAt
