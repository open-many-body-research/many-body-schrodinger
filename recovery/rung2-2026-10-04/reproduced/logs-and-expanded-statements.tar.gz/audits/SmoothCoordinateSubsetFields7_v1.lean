import SmoothCoordinateSubsetFields7_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.normedComplexDirectionalWordDeriv
#check @TheoremT.Continuum.normedComplexDirectionalWordDeriv_contDiff
#check @TheoremT.Continuum.normedComplexDirectionalWordDeriv_append
#check @TheoremT.Continuum.normedComplexDirectionalWordDeriv_perm
#check @TheoremT.Continuum.coordinateWordDeriv7
#check @TheoremT.Continuum.canonicalSubsetWord7
#check @TheoremT.Continuum.canonicalSubsetWord7_nodup
#check @TheoremT.Continuum.canonicalSubsetWord7_insert_perm
#check @TheoremT.Continuum.canonicalSubsetWord7_append_length
#check @TheoremT.Continuum.smoothSubsetField7
#check @TheoremT.Continuum.smoothSubsetField7_empty
#check @TheoremT.Continuum.smoothSubsetField7_contDiff
#check @TheoremT.Continuum.smoothSubsetField7_word_base
#check @TheoremT.Continuum.smoothSubsetField7_directional
#check @TheoremT.Continuum.smoothSubsetField7_coordinate_hasDerivAt
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.normedComplexDirectionalWordDeriv
#print axioms TheoremT.Continuum.normedComplexDirectionalWordDeriv_contDiff
#print axioms TheoremT.Continuum.normedComplexDirectionalWordDeriv_append
#print axioms TheoremT.Continuum.normedComplexDirectionalWordDeriv_perm
#print axioms TheoremT.Continuum.coordinateWordDeriv7
#print axioms TheoremT.Continuum.canonicalSubsetWord7
#print axioms TheoremT.Continuum.canonicalSubsetWord7_nodup
#print axioms TheoremT.Continuum.canonicalSubsetWord7_insert_perm
#print axioms TheoremT.Continuum.canonicalSubsetWord7_append_length
#print axioms TheoremT.Continuum.smoothSubsetField7
#print axioms TheoremT.Continuum.smoothSubsetField7_empty
#print axioms TheoremT.Continuum.smoothSubsetField7_contDiff
#print axioms TheoremT.Continuum.smoothSubsetField7_word_base
#print axioms TheoremT.Continuum.smoothSubsetField7_directional
#print axioms TheoremT.Continuum.smoothSubsetField7_coordinate_hasDerivAt
