import FiniteCoordinateProductDerivatives_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.coordinateProduct
#check @TheoremT.Continuum.coordinateProduct_contDiff
#check @TheoremT.Continuum.scalar_comp_clm_directional
#check @TheoremT.Continuum.coordinateProduct_first
#check @TheoremT.Continuum.coordinateProduct_update
#check @TheoremT.Continuum.coordinateProduct_second
#check @TheoremT.Continuum.coordinateProduct_first_bound
#check @TheoremT.Continuum.coordinateProduct_second_bound
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.coordinateProduct
#print axioms TheoremT.Continuum.coordinateProduct_contDiff
#print axioms TheoremT.Continuum.scalar_comp_clm_directional
#print axioms TheoremT.Continuum.coordinateProduct_first
#print axioms TheoremT.Continuum.coordinateProduct_update
#print axioms TheoremT.Continuum.coordinateProduct_second
#print axioms TheoremT.Continuum.coordinateProduct_first_bound
#print axioms TheoremT.Continuum.coordinateProduct_second_bound
