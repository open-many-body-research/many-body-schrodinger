import GenericWeakWordMollification_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.GenericMollifier.complexDirectionalWordDeriv
#check @TheoremT.Continuum.GenericMollifier.complexDirectionalWordDeriv_contDiff
#check @TheoremT.Continuum.GenericMollifier.mollify_word_commute
#check @TheoremT.Continuum.GenericMollifier.mollifyLp_word_ae
#check @TheoremT.Continuum.GenericMollifier.weak_word_mollification
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.GenericMollifier.complexDirectionalWordDeriv
#print axioms TheoremT.Continuum.GenericMollifier.complexDirectionalWordDeriv_contDiff
#print axioms TheoremT.Continuum.GenericMollifier.mollify_word_commute
#print axioms TheoremT.Continuum.GenericMollifier.mollifyLp_word_ae
#print axioms TheoremT.Continuum.GenericMollifier.weak_word_mollification
