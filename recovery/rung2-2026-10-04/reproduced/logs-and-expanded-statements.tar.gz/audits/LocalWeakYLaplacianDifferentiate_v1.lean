import LocalWeakYLaplacianDifferentiate_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.WeakGrushin.splitGrushin_zero_directional_commute
#check @TheoremT.Continuum.WeakGrushin.local_weak_y_laplacian_differentiate
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.WeakGrushin.splitGrushin_zero_directional_commute
#print axioms TheoremT.Continuum.WeakGrushin.local_weak_y_laplacian_differentiate
