import SpectatorWordFDeriv_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.WeakGrushin.spectatorWordDirections
#check @TheoremT.Continuum.WeakGrushin.spectatorWordDirections_norm
#check @TheoremT.Continuum.WeakGrushin.spectatorWordDeriv_eq_iteratedFDeriv
#check @TheoremT.Continuum.WeakGrushin.spectatorWordDeriv_abs_le_iteratedFDeriv
#check @TheoremT.Continuum.WeakGrushin.spectatorWordDeriv_finite_bound
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.WeakGrushin.spectatorWordDirections
#print axioms TheoremT.Continuum.WeakGrushin.spectatorWordDirections_norm
#print axioms TheoremT.Continuum.WeakGrushin.spectatorWordDeriv_eq_iteratedFDeriv
#print axioms TheoremT.Continuum.WeakGrushin.spectatorWordDeriv_abs_le_iteratedFDeriv
#print axioms TheoremT.Continuum.WeakGrushin.spectatorWordDeriv_finite_bound
