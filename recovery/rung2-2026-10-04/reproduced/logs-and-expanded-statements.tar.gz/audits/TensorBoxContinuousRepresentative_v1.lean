import TensorBoxContinuousRepresentative_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.tensor_box7_uniform_limit_ae_Lp_limit
#check @TheoremT.Continuum.tensor_box7_continuous_representative_of_L2_limits
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.tensor_box7_uniform_limit_ae_Lp_limit
#print axioms TheoremT.Continuum.tensor_box7_continuous_representative_of_L2_limits
