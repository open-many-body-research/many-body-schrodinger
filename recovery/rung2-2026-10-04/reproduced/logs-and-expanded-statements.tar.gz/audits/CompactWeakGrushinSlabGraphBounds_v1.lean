import CompactWeakGrushinSlabGraphBounds_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.WeakGrushin.compact_weakH2_slab_graph_bounds_output
#check @TheoremT.Continuum.WeakGrushin.compact_weakH2_slab_graph_bounds_on_compact
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.WeakGrushin.compact_weakH2_slab_graph_bounds_output
#print axioms TheoremT.Continuum.WeakGrushin.compact_weakH2_slab_graph_bounds_on_compact
