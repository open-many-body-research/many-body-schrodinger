import SpectatorIterationState_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.WeakGrushin.RegionL2Budget
#check @TheoremT.Continuum.WeakGrushin.RegionL2Budget.restrict
#check @TheoremT.Continuum.WeakGrushin.RegionL2Budget.local
#check @TheoremT.Continuum.WeakGrushin.regionL2Budget_of_global
#check @TheoremT.Continuum.WeakGrushin.LocalYDerivative
#check @TheoremT.Continuum.WeakGrushin.LocalYDerivative.mono
#check @TheoremT.Continuum.WeakGrushin.SpectatorFiniteState
#check @TheoremT.Continuum.WeakGrushin.spectatorFiniteState_zero
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.WeakGrushin.RegionL2Budget
#print axioms TheoremT.Continuum.WeakGrushin.RegionL2Budget.restrict
#print axioms TheoremT.Continuum.WeakGrushin.RegionL2Budget.local
#print axioms TheoremT.Continuum.WeakGrushin.regionL2Budget_of_global
#print axioms TheoremT.Continuum.WeakGrushin.LocalYDerivative
#print axioms TheoremT.Continuum.WeakGrushin.LocalYDerivative.mono
#print axioms TheoremT.Continuum.WeakGrushin.SpectatorFiniteState
#print axioms TheoremT.Continuum.WeakGrushin.spectatorFiniteState_zero
