import GrushinFactorialPrincipalMultiplicity_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.WeakGrushin.factorial_diagonal_pair_count_le
#check @TheoremT.Continuum.WeakGrushin.factorial_fin4_fin3_norm_sum_le
#check @TheoremT.Continuum.WeakGrushin.factorial_principal_multiplicity_norm_bound
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.WeakGrushin.factorial_diagonal_pair_count_le
#print axioms TheoremT.Continuum.WeakGrushin.factorial_fin4_fin3_norm_sum_le
#print axioms TheoremT.Continuum.WeakGrushin.factorial_principal_multiplicity_norm_bound
