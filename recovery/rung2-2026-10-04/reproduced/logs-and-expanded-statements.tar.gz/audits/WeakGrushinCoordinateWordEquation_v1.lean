import WeakGrushinCoordinateWordEquation_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.WeakGrushin.coordinateWordYSource
#check @TheoremT.Continuum.WeakGrushin.coordinateWordGrushinSource
#check @TheoremT.Continuum.WeakGrushin.coordinateWordGrushinSource_eq
#check @TheoremT.Continuum.WeakGrushin.weak_grushin_coordinate_word_equations
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.WeakGrushin.coordinateWordYSource
#print axioms TheoremT.Continuum.WeakGrushin.coordinateWordGrushinSource
#print axioms TheoremT.Continuum.WeakGrushin.coordinateWordGrushinSource_eq
#print axioms TheoremT.Continuum.WeakGrushin.weak_grushin_coordinate_word_equations
