import KSScaledAffineWeakForcing_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.ksScaledPrincipal_const
#check @TheoremT.Continuum.ks_scaled_constant_weak_pairing
#check @TheoremT.Continuum.ks_scaled_affine_weak_forcing
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.ksScaledPrincipal_const
#print axioms TheoremT.Continuum.ks_scaled_constant_weak_pairing
#print axioms TheoremT.Continuum.ks_scaled_affine_weak_forcing
