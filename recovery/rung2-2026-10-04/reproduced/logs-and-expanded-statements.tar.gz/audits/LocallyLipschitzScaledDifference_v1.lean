import LocallyLipschitzScaledDifference_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.originScaledDifference
#check @TheoremT.Continuum.originScaledDifference_norm_le
#check @TheoremT.Continuum.locallyLipschitz_origin_ball
#check @TheoremT.Continuum.locallyLipschitz_scaled_difference_uniform
#check @TheoremT.Continuum.originScaledDifference_continuous
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.originScaledDifference
#print axioms TheoremT.Continuum.originScaledDifference_norm_le
#print axioms TheoremT.Continuum.locallyLipschitz_origin_ball
#print axioms TheoremT.Continuum.locallyLipschitz_scaled_difference_uniform
#print axioms TheoremT.Continuum.originScaledDifference_continuous
