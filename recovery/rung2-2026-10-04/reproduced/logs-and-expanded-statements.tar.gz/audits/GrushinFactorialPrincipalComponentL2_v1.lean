import GrushinFactorialPrincipalComponentL2_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.WeakGrushin.factorialOuterIndex_norm_le
#check @TheoremT.Continuum.WeakGrushin.factorialYMonomial_single
#check @TheoremT.Continuum.WeakGrushin.factorial_principal_one_hit_component_L2
#check @TheoremT.Continuum.WeakGrushin.factorial_principal_two_hit_component_L2
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.WeakGrushin.factorialOuterIndex_norm_le
#print axioms TheoremT.Continuum.WeakGrushin.factorialYMonomial_single
#print axioms TheoremT.Continuum.WeakGrushin.factorial_principal_one_hit_component_L2
#print axioms TheoremT.Continuum.WeakGrushin.factorial_principal_two_hit_component_L2
