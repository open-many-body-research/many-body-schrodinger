import ProductSevenCoordinateTransport_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.sevenToProduct
#check @TheoremT.Continuum.sevenToProduct_measurePreserving
#check @TheoremT.Continuum.sevenToProduct_direction
#check @TheoremT.Continuum.sevenToProduct_word_chain
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.sevenToProduct
#print axioms TheoremT.Continuum.sevenToProduct_measurePreserving
#print axioms TheoremT.Continuum.sevenToProduct_direction
#print axioms TheoremT.Continuum.sevenToProduct_word_chain
