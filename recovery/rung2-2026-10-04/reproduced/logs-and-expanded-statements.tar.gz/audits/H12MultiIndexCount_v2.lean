import H12MultiIndexCount_v2
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.boundedMultiIndex
#check @TheoremT.Continuum.boundedMultiIndex_slack_equiv
#check @TheoremT.Continuum.boundedMultiIndex_sym_equiv
#check @TheoremT.Continuum.boundedMultiIndex_fintype
#check @TheoremT.Continuum.boundedMultiIndex_card
#check @TheoremT.Continuum.h12MultiIndices
#check @TheoremT.Continuum.h12MultiIndices_card
#check @TheoremT.Continuum.h12MultiIndex_total_order
#check @TheoremT.Continuum.h12MultiIndex_exhaustive
#check @TheoremT.Continuum.h12MultiIndexNormSq
#check @TheoremT.Continuum.h12MultiIndexNormSq_nonneg
#check @TheoremT.Continuum.h12MultiIndexNormSq_le
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.boundedMultiIndex
#print axioms TheoremT.Continuum.boundedMultiIndex_slack_equiv
#print axioms TheoremT.Continuum.boundedMultiIndex_sym_equiv
#print axioms TheoremT.Continuum.boundedMultiIndex_fintype
#print axioms TheoremT.Continuum.boundedMultiIndex_card
#print axioms TheoremT.Continuum.h12MultiIndices
#print axioms TheoremT.Continuum.h12MultiIndices_card
#print axioms TheoremT.Continuum.h12MultiIndex_total_order
#print axioms TheoremT.Continuum.h12MultiIndex_exhaustive
#print axioms TheoremT.Continuum.h12MultiIndexNormSq
#print axioms TheoremT.Continuum.h12MultiIndexNormSq_nonneg
#print axioms TheoremT.Continuum.h12MultiIndexNormSq_le
