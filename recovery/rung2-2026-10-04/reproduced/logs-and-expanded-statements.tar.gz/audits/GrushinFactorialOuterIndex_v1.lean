import GrushinFactorialOuterIndex_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.WeakGrushin.FactorialOuterIndex
#check @TheoremT.Continuum.WeakGrushin.factorialOuterAdmissible
#check @TheoremT.Continuum.WeakGrushin.factorialOuterIndices
#check @TheoremT.Continuum.WeakGrushin.factorialOuterIndices_mem
#check @TheoremT.Continuum.WeakGrushin.factorialOuterAdmissible_original
#check @TheoremT.Continuum.WeakGrushin.factorialSquareOuterIndex
#check @TheoremT.Continuum.WeakGrushin.factorialSquareOuterIndex_mem
#check @TheoremT.Continuum.WeakGrushin.factorialSquareOuterIndex_injective
#check @TheoremT.Continuum.WeakGrushin.factorialOuterNorm
#check @TheoremT.Continuum.WeakGrushin.factorialSquareOuterIndex_norm_sum_le
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.WeakGrushin.FactorialOuterIndex
#print axioms TheoremT.Continuum.WeakGrushin.factorialOuterAdmissible
#print axioms TheoremT.Continuum.WeakGrushin.factorialOuterIndices
#print axioms TheoremT.Continuum.WeakGrushin.factorialOuterIndices_mem
#print axioms TheoremT.Continuum.WeakGrushin.factorialOuterAdmissible_original
#print axioms TheoremT.Continuum.WeakGrushin.factorialSquareOuterIndex
#print axioms TheoremT.Continuum.WeakGrushin.factorialSquareOuterIndex_mem
#print axioms TheoremT.Continuum.WeakGrushin.factorialSquareOuterIndex_injective
#print axioms TheoremT.Continuum.WeakGrushin.factorialOuterNorm
#print axioms TheoremT.Continuum.WeakGrushin.factorialSquareOuterIndex_norm_sum_le
