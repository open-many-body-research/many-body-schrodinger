import ExpNegInvGlueExplicitBounds_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.nonnegative_monomial_exp_neg_bound
#check @TheoremT.Continuum.expNegInvGlue_polynomial_bound
#check @TheoremT.Continuum.expNegInvGlue_deriv_formula
#check @TheoremT.Continuum.expNegInvGlue_second_deriv_formula
#check @TheoremT.Continuum.expNegInvGlue_deriv_abs_le_two
#check @TheoremT.Continuum.expNegInvGlue_second_deriv_abs_le_thirty_six
#check @TheoremT.Continuum.smoothTransition_denom_lower
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.nonnegative_monomial_exp_neg_bound
#print axioms TheoremT.Continuum.expNegInvGlue_polynomial_bound
#print axioms TheoremT.Continuum.expNegInvGlue_deriv_formula
#print axioms TheoremT.Continuum.expNegInvGlue_second_deriv_formula
#print axioms TheoremT.Continuum.expNegInvGlue_deriv_abs_le_two
#print axioms TheoremT.Continuum.expNegInvGlue_second_deriv_abs_le_thirty_six
#print axioms TheoremT.Continuum.smoothTransition_denom_lower
