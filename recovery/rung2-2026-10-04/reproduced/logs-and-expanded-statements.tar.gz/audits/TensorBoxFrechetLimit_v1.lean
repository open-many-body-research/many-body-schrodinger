import TensorBoxFrechetLimit_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.coordinateDerivativeMap7
#check @TheoremT.Continuum.coordinateDerivativeMap7_fderiv
#check @TheoremT.Continuum.tensor_box7_uniformly_pi
#check @TheoremT.Continuum.tensor_box7_fderiv_uniform_limit
#check @TheoremT.Continuum.tensor_box7_limit_hasFDerivAt
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.coordinateDerivativeMap7
#print axioms TheoremT.Continuum.coordinateDerivativeMap7_fderiv
#print axioms TheoremT.Continuum.tensor_box7_uniformly_pi
#print axioms TheoremT.Continuum.tensor_box7_fderiv_uniform_limit
#print axioms TheoremT.Continuum.tensor_box7_limit_hasFDerivAt
