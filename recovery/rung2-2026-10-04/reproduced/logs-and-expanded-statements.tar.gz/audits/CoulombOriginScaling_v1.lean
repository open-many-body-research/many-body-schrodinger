import CoulombOriginScaling_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.collisionFree_real_smul
#check @TheoremT.Continuum.smoothLaplacian_comp_real_smul_at
#check @TheoremT.Continuum.scalar_coulomb_origin_scaled_classical_equation
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.collisionFree_real_smul
#print axioms TheoremT.Continuum.smoothLaplacian_comp_real_smul_at
#print axioms TheoremT.Continuum.scalar_coulomb_origin_scaled_classical_equation
