import GrushinFiniteNestedGeometry_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.WeakGrushin.finite_grushin_nested_geometry
#check @TheoremT.Continuum.WeakGrushin.finite_grushin_nested_final_contains
#check @TheoremT.Continuum.WeakGrushin.finite_grushin_nested_domains
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.WeakGrushin.finite_grushin_nested_geometry
#print axioms TheoremT.Continuum.WeakGrushin.finite_grushin_nested_final_contains
#print axioms TheoremT.Continuum.WeakGrushin.finite_grushin_nested_domains
