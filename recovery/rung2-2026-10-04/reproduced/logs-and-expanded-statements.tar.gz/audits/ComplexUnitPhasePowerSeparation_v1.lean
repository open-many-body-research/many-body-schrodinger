import ComplexUnitPhasePowerSeparation_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.complex_exists_unit_phase_pow_ne
#check @TheoremT.Continuum.complex_nat_eq_of_unit_phase_pow_eq
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.complex_exists_unit_phase_pow_ne
#print axioms TheoremT.Continuum.complex_nat_eq_of_unit_phase_pow_eq
