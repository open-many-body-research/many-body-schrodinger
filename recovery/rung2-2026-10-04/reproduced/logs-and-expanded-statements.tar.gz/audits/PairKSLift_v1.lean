import PairKSLift_v1
set_option pp.all true
set_option pp.universes true
set_option pp.instances false
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option maxRecDepth 16384
set_option pp.rawOnError true
#check @TheoremT.Continuum.PairKSSpace
#check @TheoremT.Continuum.pairSpectatorCoordinateEquiv
#check @TheoremT.Continuum.pairCenterEquiv
#check @TheoremT.Continuum.pairCenterEquiv_apply
#check @TheoremT.Continuum.pairCenterEquiv_basis
#check @TheoremT.Continuum.pairCenterEquiv_measurePreserving
#check @TheoremT.Continuum.pairCoordinatesLinear
#check @TheoremT.Continuum.pairCoordinates
#check @TheoremT.Continuum.pairCoordinates_first
#check @TheoremT.Continuum.pairCoordinates_second
#check @TheoremT.Continuum.pairCoordinates_first_basis
#check @TheoremT.Continuum.pairCoordinates_spectator_basis
#check @TheoremT.Continuum.pairKSLift
#check @TheoremT.Continuum.pairKSLift_contDiff
#check @TheoremT.Continuum.pairKSLift_locallyLipschitz
#check @TheoremT.Continuum.pairKSLift_first
#check @TheoremT.Continuum.pairKSLift_second
#check @TheoremT.Continuum.pairKSLift_difference
#check @TheoremT.Continuum.pairKSLift_pair_radius
set_option pp.all false
set_option pp.universes false
#print axioms TheoremT.Continuum.PairKSSpace
#print axioms TheoremT.Continuum.pairSpectatorCoordinateEquiv
#print axioms TheoremT.Continuum.pairCenterEquiv
#print axioms TheoremT.Continuum.pairCenterEquiv_apply
#print axioms TheoremT.Continuum.pairCenterEquiv_basis
#print axioms TheoremT.Continuum.pairCenterEquiv_measurePreserving
#print axioms TheoremT.Continuum.pairCoordinatesLinear
#print axioms TheoremT.Continuum.pairCoordinates
#print axioms TheoremT.Continuum.pairCoordinates_first
#print axioms TheoremT.Continuum.pairCoordinates_second
#print axioms TheoremT.Continuum.pairCoordinates_first_basis
#print axioms TheoremT.Continuum.pairCoordinates_spectator_basis
#print axioms TheoremT.Continuum.pairKSLift
#print axioms TheoremT.Continuum.pairKSLift_contDiff
#print axioms TheoremT.Continuum.pairKSLift_locallyLipschitz
#print axioms TheoremT.Continuum.pairKSLift_first
#print axioms TheoremT.Continuum.pairKSLift_second
#print axioms TheoremT.Continuum.pairKSLift_difference
#print axioms TheoremT.Continuum.pairKSLift_pair_radius
